# Plan — Prototipo RadiografIA

## Contexto
Prototipo estático de un analizador de estilo en español que explica si un texto suena a asistente y por qué, sin porcentajes, semáforos ni afirmaciones de autoría. 6 pantallas × 3 tamaños (1280 / 820 / 390), salvo la de impresión (solo A4). Fuente única: `guidelines.md` (raíz), que se lee al inicio de cada prompt; si un prompt choca con él, manda el fichero y lo señalo.

## Enfoque
- **Sin librería de componentes**: todo propio con Tailwind v4; los tokens de `guidelines.md` en `@theme` de `src/index.css` son la única fuente de estilo. Literata + Atkinson Hyperlegible Next por `@import` de Google Fonts.
- Se conserva `src/main.tsx`; `src/App.tsx` pasa a ser un selector de marcos por hash, sin router. Cada pantalla es un marco de ancho fijo, aislado, para copiarlo como capas.
- Datos de ejemplo en `src/datos/*.ts`, con las cadenas literales tal como me las des. No invento reglas, familias ni textos.
- Reglas duras: subrayado fino sin fondo; color + estilo de línea + sigla + nombre de categoría en texto; AA; foco 2 px accent con 2 px de separación; 44 px; sin scroll horizontal a 320 px; tramos como `<span role="button" tabindex="0">` con nombre accesible y teclado según el patrón «button» de WAI-ARIA APG (Chrome fuerza inline-block en `<button>` y no se partiría entre líneas); tarjeta de escritorio/tableta como diálogo no modal (Escape cierra); hoja inferior como diálogo modal que atrapa foco, devuelve el foco al tramo y no tapa el tramo activo.

## Componentes reutilizables (`src/componentes/`)
- **PastillaResultado** — 7 variantes: las seis etiquetas literales («Texto sin indicios de Asistente IA», «Texto con muy pocos rasgos que indiquen que tiene Asistente IA», «Dentro de lo normal», «Texto con bastantes rasgos de Asistente IA», «Texto con muchos rasgos de Asistente IA», «No podemos comparar»), cada una con su frase debajo, más una variante con aviso de texto corto. Etiqueta a 28 px; sin colores semafóricos.
- **TramoSubrayado** — botón inline con el subrayado y la sigla de su categoría.
- **TarjetaRegla** — orden fijo: nombre → frase en claro → «Qué hacer» → «¿Por qué lo miramos?» plegado (explicación, evidencia, origen, paquete, enlace a la ficha) → «Anterior» y «Siguiente» → cierre. La misma tarjeta se usa anclada (escritorio/tableta) y dentro de HojaInferior (móvil).
- **HojaInferior** — diálogo modal móvil con botón asa etiquetado; contiene TarjetaRegla.
- **TarjetaFamilia** — familia con ojo (mostrar/ocultar subrayados).
- **BarraPestanas** — solo móvil, fija abajo: «Texto · Reglas · Datos».
- Auxiliares: Sigla, Boton (44 px), CabeceraApp, AreaTexto, Leyenda, Desglose, FilaRegla, MarcoPantalla.

## Orden de construcción (un paso por pantalla y tamaño)
0. Tokens y fuentes en `src/index.css`, `tokens.json` (formato DTCG 2025.10, pedido en guidelines), MarcoPantalla y selector.
1. Analizador vacío — escritorio · 2. tableta · 3. móvil
4. Analizador con resultado — escritorio · 5. tableta · 6. móvil
7. Tarjeta de regla — escritorio · 8. tableta (anclada bajo el tramo) · 9. móvil (hoja inferior)
10. Catálogo de reglas — escritorio · 11. tableta · 12. móvil
13. Ficha de regla — escritorio · 14. tableta · 15. móvil
16. Vista de impresión — A4 en pantalla (secciones numeradas, sin botones, URL tras enlaces, sigla tras cada tramo, Literata 11 pt, márgenes 20/18 mm).

Tableta: una sola columna con los componentes de escritorio, sin BarraPestanas.

## Nombres de capa
- Atributo `data-capa` en cada bloque, con los nombres de guidelines.md: `resultado`, `pastilla`, `tarjeta-regla`, `tramo`, `leyenda`, `desglose`, `hoja-inferior`, `barra-pestanas`.
- Marcos: `Pantalla / <pantalla> / Escritorio | Tableta | Móvil`.
- Tramos y tarjetas con nombres sacados solo de los datos: `Tramo – <nombre de la regla> (<sigla>)`, `Tarjeta de regla – <nombre de la regla> (<sigla>)`.
- Nada genérico (`div`, `wrapper`, `Frame 12`).

## Verificación
Revisión visual de cada marco a su ancho; 320 px sin scroll horizontal; teclado (foco visible, tramos alcanzables, Escape).
