export type VariantePastilla = 'sin-indicios' | 'muy-pocos' | 'normal' | 'bastantes' | 'muchos' | 'no-comparable'

export const PASTILLAS: Record<VariantePastilla, { etiqueta: string; frase: string }> = {
  'sin-indicios': { etiqueta: 'Texto sin indicios de Asistente IA', frase: 'Aquí no hay nada que suene a asistente (IA).' },
  'muy-pocos': {
    etiqueta: 'Texto con muy pocos rasgos que indiquen que tiene Asistente IA',
    frase: 'Tu texto suena menos a asistente (IA) que una crítica de cine normal escrita por una persona.',
  },
  normal: { etiqueta: 'Dentro de lo normal', frase: 'Suena como cualquier crítica de cine escrita por una persona. Nada raro.' },
  bastantes: {
    etiqueta: 'Texto con bastantes rasgos de Asistente IA',
    frase: 'Tu texto suena bastante a asistente (IA): de cada 100 textos escritos por personas, solo 5 suenan tanto.',
  },
  muchos: {
    etiqueta: 'Texto con muchos rasgos de Asistente IA',
    frase: 'Tu texto suena mucho a asistente (IA): de cada 100 críticas de cine escritas por personas, solo 1 suena tanto.',
  },
  'no-comparable': {
    etiqueta: 'No podemos comparar',
    frase: 'No tenemos críticas de cine de este tamaño escritas por personas con las que comparar. Mira el detalle.',
  },
}

export const AVISO_TEXTO_CORTO = 'Ojo: tu texto es corto (menos de 300 palabras). Tómate el resultado como orientativo.'
