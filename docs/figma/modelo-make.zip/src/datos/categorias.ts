export type Categoria = { id: string; nombre: string; sigla: string; color: string; estilo: string }

export const CATEGORIAS: Categoria[] = [
  { id: 'lexico', nombre: 'Léxico', sigla: 'L', color: '#0072B2', estilo: 'continuo 2 px' },
  { id: 'discurso', nombre: 'Discurso', sigla: 'D', color: '#882255', estilo: 'continuo 3 px' },
  { id: 'sintaxis', nombre: 'Sintaxis', sigla: 'S', color: '#D55E00', estilo: 'discontinuo 2 px' },
  { id: 'estadistica', nombre: 'Estadística', sigla: 'E', color: '#332288', estilo: 'doble 1 px' },
  { id: 'puntuacion', nombre: 'Puntuación y formato', sigla: 'P', color: '#009E73', estilo: 'punteado 3 px' },
  { id: 'canal', nombre: 'Canal (informativa)', sigla: 'C', color: '#117733', estilo: 'punteado 1 px' },
  { id: 'gramatica', nombre: 'Gramática (Español correcto)', sigla: 'G', color: '#AA4499', estilo: 'ondulado 2 px' },
  { id: 'ortotipografia', nombre: 'Ortotipografía (Español correcto)', sigla: 'O', color: '#CC6677', estilo: 'doble discontinuo' },
]
