import { CATEGORIAS } from './categorias'
import { TRAMOS } from './resultadoEjemplo'

// Ficha que muestra la tarjeta de regla. Los textos entre corchetes son relleno pendiente.
export type Ficha = {
  titulo: string
  familia?: string // id de categoría; ausente en reglas de paquete propio
  linea: string
  frase: string
  queHacer: string
  porQue?: string
  evidencia: string
  origen?: string
  paquete?: string
  enlace?: boolean
  nota?: string
}

export const FICHA_CONECTOR: Ficha = {
  titulo: 'Conector repetido',
  familia: 'discurso',
  linea: 'Discurso · RadiografIA',
  frase: 'El mismo conector al principio de tres frases o más, como «Además» una y otra vez.',
  queHacer: 'Cambia alguno de los conectores repetidos o quítalo: muchas veces la frase se entiende sin él.',
  porQue: '[Explicación de la ficha: dos o tres frases.]',
  evidencia: 'medido en inglés',
  origen: '[origen de la ficha]',
  paquete: 'RadiografIA 0.1.0',
  enlace: true,
}

export const FICHA_PAQUETE_PROPIO: Ficha = {
  titulo: 'Uso de «a nivel de»',
  linea: 'Pruebas · Paquete de prueba 1.0.0',
  frase: 'La muletilla «a nivel de» donde basta «en» o «respecto a».',
  queHacer: 'Sustitúyela por «en», «entre» o «respecto a».',
  evidencia: 'anecdótico',
  nota: 'Regla de un paquete propio: sin página en el catálogo',
}

// PENDIENTE: el prompt solo da la ficha de «Conector repetido»; el resto lleva relleno marcado
export function fichaDeTramo(i: number): Ficha {
  const t = TRAMOS[i]
  const c = CATEGORIAS.find((x) => x.id === t.familias[0])!
  if (t.regla === 'Conector repetido') return FICHA_CONECTOR
  return {
    titulo: t.regla ?? '[Nombre de la regla]',
    familia: c.id,
    linea: `${c.nombre} · RadiografIA`,
    frase: '[Descripción de la regla: una frase.]',
    queHacer: '[Consejo de la ficha.]',
    porQue: '[Explicación de la ficha: dos o tres frases.]',
    evidencia: '[nivel de evidencia]',
    origen: '[origen de la ficha]',
    paquete: 'RadiografIA 0.1.0',
    enlace: true,
  }
}

export const PRIMER_ADEMAS = TRAMOS.findIndex((t) => t.texto === 'Además')
