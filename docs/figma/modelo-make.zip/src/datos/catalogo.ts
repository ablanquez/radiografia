// Catálogo de reglas: filtros y las seis tarjetas de muestra dadas en el prompt
export const TOTAL_REGLAS = 50

export const FILTRO_FAMILIAS = [
  { id: 'canal', nombre: 'Canal (RadiografIA)' },
  { id: 'discurso', nombre: 'Discurso (RadiografIA)' },
  { id: 'estadistica', nombre: 'Estadística (RadiografIA)' },
  { id: 'lexico', nombre: 'Léxico (RadiografIA)' },
  { id: 'puntuacion', nombre: 'Puntuación y formato (RadiografIA)' },
  { id: 'sintaxis', nombre: 'Sintaxis (RadiografIA)' },
  { id: 'gramatica', nombre: 'Gramática (Español correcto)' },
  { id: 'ortotipografia', nombre: 'Ortotipografía (Español correcto)' },
]
export const FILTRO_DETECTORES = ['estadístico', 'estructural', 'patrón']
export const FILTRO_SEVERIDADES = ['baja', 'media', 'alta']

export type ReglaCatalogo = { nombre: string; frase: string; id: string; paquete: string; detector: string; evidencia: string; familia: string; informativa?: boolean }

export const REGLAS_MUESTRA: ReglaCatalogo[] = [
  { nombre: 'Conector repetido', frase: 'El mismo conector al principio de tres frases o más, como «Además» una y otra vez.', id: 'disc-marcador-repetido', paquete: 'RadiografIA', detector: 'estructural', evidencia: 'medido en inglés', familia: 'discurso' },
  { nombre: 'Frases cortas', frase: 'Muchas frases para tan pocas palabras, comparado con textos de personas del mismo tipo y longitud.', id: 'est-frases-cortas', paquete: 'RadiografIA', detector: 'estadístico', evidencia: 'medido en español', familia: 'estadistica' },
  { nombre: 'Coletilla de gerundio final', frase: 'Frases que acaban en una coletilla con gerundio tras una coma, como «…, logrando un récord».', id: 'sint-gerundio-adjunto-final', paquete: 'RadiografIA', detector: 'patrón', evidencia: 'medido en inglés', familia: 'sintaxis' },
  { nombre: 'Calcos léxicos del inglés', frase: 'Palabras que suenan a traducción del inglés, como «profundizar», «intrincado» o «meticuloso».', id: 'lex-traslados-del-ingles', paquete: 'RadiografIA', detector: 'patrón', evidencia: 'anecdótico', familia: 'lexico' },
  { nombre: 'Mes o día con mayúscula', frase: 'Meses y días de la semana con mayúscula dentro de la frase, como «el Lunes 3 de Marzo».', id: 'orto-mes-o-dia-con-mayuscula', paquete: 'Español correcto', detector: 'patrón', evidencia: 'norma', familia: 'ortotipografia' },
  { nombre: 'Negrita de Markdown', frase: 'Asteriscos dobles como **así**, pegados tal cual: el formato del chat sin convertir. Solo avisa.', id: 'canal-negrita-markdown', paquete: 'RadiografIA', detector: 'patrón', evidencia: 'medido en inglés', familia: 'canal', informativa: true },
]
