// Datos de ejemplo del prompt 2, tal cual
export const TEXTO_EJEMPLO = `## Cinco Claves Para Mejorar Tu Productividad En El Trabajo
La productividad se ha convertido en uno de los temas más relevantes del mundo laboral. En este artículo exploraremos cinco claves que pueden transformar la forma de trabajar de cualquier empresa, mejorando la concentración de todo el equipo.
El método fue desarrollado por un equipo de psicólogos de la Universidad de Stanford en 2019. Desde entonces, más de 1,500 empresas lo han adoptado, y su licencia básica cuesta $100 al año. Los expertos coinciden en que su impacto es notable.
La primera clave es planificar la semana. Cada Lunes, antes de abrir el correo, conviene dedicar diez minutos a fijar las prioridades. La próxima sesión de formación será el Lunes 3 de Marzo, y la inscripción ya está abierta.
La segunda clave es la comunicación. En la última reunión, la directora levantó su mano y pidió silencio antes de explicar el nuevo sistema. Su mensaje fue claro: «menos reuniones y más resultados.» Además, cada equipo recibió una guía práctica.
La tercera clave es desconectar. Diversos estudios demuestran que las pausas breves mejoran el rendimiento. Además, reducir las notificaciones del móvil desempeña un papel fundamental en la concentración, permitiendo centrarse en las tareas importantes.
La cuarta clave es delegar. Muchos directivos siguen revisando cada documento antes de enviarlo, aunque sus equipos están preparados para hacerlo solos. Delegar no significa desentenderse: significa confiar, dar instrucciones claras y revisar los resultados al final de la semana, no a cada paso. Además, las empresas que lo han probado dicen que las decisiones llegan antes y que los empleados se sienten más valorados.
La quinta clave es medir. Sin datos, cualquier cambio es una intuición; con ellos, es posible saber qué funciona y qué no. Una hoja de cálculo sencilla basta para anotar las horas dedicadas a cada proyecto y compararlas con los objetivos.
En conclusión, mejorar la productividad no depende de trabajar más horas, sino de trabajar mejor. Con planificación, comunicación y pausas, cualquier equipo puede alcanzar sus objetivos.`

// Tramos en orden de aparición. `regla` solo cuando el prompt da su nombre.
export type Tramo = { texto: string; familias: string[]; regla?: string }

export const TRAMOS: Tramo[] = [
  { texto: '## Cinco Claves Para Mejorar Tu Productividad En El Trabajo', familias: ['canal', 'ortotipografia'] },
  { texto: 'En este artículo exploraremos', familias: ['lexico'] },
  { texto: 'mejorando la concentración de todo el equipo.', familias: ['sintaxis'], regla: 'Coletilla de gerundio final' },
  { texto: 'fue desarrollado', familias: ['gramatica'], regla: 'Pasiva perifrástica con agente' },
  { texto: '1,500', familias: ['ortotipografia'] },
  { texto: '$100', familias: ['ortotipografia'] },
  { texto: 'Los expertos coinciden', familias: ['discurso'], regla: 'Atribución vaga' },
  { texto: 'Lunes', familias: ['ortotipografia'], regla: 'Mes o día con mayúscula' },
  { texto: 'Lunes', familias: ['ortotipografia'], regla: 'Mes o día con mayúscula' },
  { texto: 'Marzo', familias: ['ortotipografia'], regla: 'Mes o día con mayúscula' },
  { texto: 'levantó su mano', familias: ['gramatica'] },
  { texto: '.', familias: ['ortotipografia'] }, // punto dentro de «resultados.»
  { texto: 'Además', familias: ['discurso'], regla: 'Conector repetido' },
  { texto: 'Diversos estudios demuestran', familias: ['discurso'], regla: 'Atribución vaga' },
  { texto: 'Además', familias: ['discurso'], regla: 'Conector repetido' },
  { texto: 'papel fundamental', familias: ['discurso'], regla: 'Importancia inflada' },
  { texto: 'permitiendo centrarse en las tareas importantes.', familias: ['sintaxis'], regla: 'Coletilla de gerundio final' },
  { texto: 'Además', familias: ['discurso'], regla: 'Conector repetido' },
  { texto: 'En conclusión', familias: ['discurso'], regla: 'Cierre de plantilla' },
]

// Para el punto de «resultados.» se busca a partir de este ancla
export const ANCLAS: Record<number, string> = { 11: 'resultados' }

export const RESULTADO = {
  variante: 'bastantes' as const,
  loQueMasPesa: [
    { nombre: 'Conector repetido', familia: 'discurso', cola: '3 veces', empiezaPor: 'Empieza por: Cambia alguno de los conectores repetidos o quítalo: muchas veces la frase se entiende sin él.' },
    { nombre: 'Coletilla de gerundio final', familia: 'sintaxis', cola: '2 veces' },
    { nombre: 'Atribución vaga', familia: 'discurso', cola: '2 veces' },
  ],
  familias: [
    { id: 'lexico', etiqueta: 'Léxico (1)' },
    { id: 'discurso', etiqueta: 'Discurso (7)' },
    { id: 'sintaxis', etiqueta: 'Sintaxis (2)' },
    { id: 'estadistica', etiqueta: 'Estadística (0)' },
    { id: 'puntuacion', etiqueta: 'Puntuación y formato (0)' },
    { id: 'gramatica', etiqueta: 'Gramática (2)' },
    { id: 'ortotipografia', etiqueta: 'Ortotipografía (7)' },
  ],
  canal: 'Canal: solo avisos (1)',
  detalleResumen:
    'Tu total: 44,08 puntos por cada 1.000 palabras. Comparado con 500 textos de 300 a 599 palabras escritos por personas: mediana 1,86 · p95 32,17 · p99 57,24. 325 palabras que cuentan · textos de 300 a 599 palabras · tipo: General.',
  desglose: [
    { familia: 'Discurso 28,69', lineas: ['Atribución vaga 2 veces · 6,15 puntos', 'Cierre de plantilla 1 vez · 1 punto', 'Conector repetido 3 veces · 18,46 puntos', 'Importancia inflada 1 vez · 3,08 puntos'] },
    { familia: 'Léxico 3,08', lineas: [] },
    { familia: 'Sintaxis 12,31', lineas: [] },
    { familia: 'Estadística 0', lineas: [] },
    { familia: 'Puntuación y formato 0', lineas: [] },
  ],
  // PENDIENTE: el prompt no da los nombres de las seis líneas
  soloAvisos: { titulo: 'Solo avisos: no suman', lineas: ['Diversidad, legibilidad y pronombres: dentro de lo habitual en los textos'] },
  noMiradas: 'No miradas en este texto: Sin marcadores de opinión ni duda y Sin primera persona: solo se miran en las críticas de cine y los textos académicos',
  espanolCorrecto: {
    resumen: '9 avisos de norma: Mes o día con mayúscula (3) y Pasiva perifrástica con agente (1).',
    lineas: ['Mes o día con mayúscula (3)', 'Pasiva perifrástica con agente (1)'],
  },
}
