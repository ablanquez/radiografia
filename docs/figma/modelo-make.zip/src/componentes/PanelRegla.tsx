import { useCallback, useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent, type ReactNode, type RefObject } from 'react'
import { fichaDeTramo } from '../datos/reglas'
import { TRAMOS } from '../datos/resultadoEjemplo'
import TarjetaRegla from './TarjetaRegla'

const tramoEn = (cont: HTMLElement | null, i: number) => cont?.querySelector<HTMLElement>(`[data-tramo="${i}"]`) ?? null
const enfocarTitulo = (caja: HTMLElement | null) => caja?.querySelector<HTMLElement>('h2')?.focus({ preventScroll: true })

// Estado de la tarjeta de regla: qué tramo está abierto, Escape cierra y el foco vuelve al tramo
export function useReglaActiva(contenedor: RefObject<HTMLElement | null>, inicial: number | null = null) {
  const [activo, setActivo] = useState<number | null>(inicial)
  const devolver = useRef<number | null>(null)
  const porUsuario = useRef(false)

  const abrir = useCallback((i: number) => {
    porUsuario.current = true
    setActivo(i)
  }, [])
  const cerrar = useCallback(() => {
    setActivo((a) => {
      devolver.current = a
      return null
    })
  }, [])
  const ir = useCallback((paso: number) => {
    porUsuario.current = true
    setActivo((a) => (a === null ? a : Math.min(TRAMOS.length - 1, Math.max(0, a + paso))))
  }, [])

  useEffect(() => {
    if (activo === null && devolver.current !== null) {
      tramoEn(contenedor.current, devolver.current)?.focus()
      devolver.current = null
    }
    if (activo === null) return
    const alTeclear = (e: globalThis.KeyboardEvent) => e.key === 'Escape' && cerrar()
    document.addEventListener('keydown', alTeclear)
    return () => document.removeEventListener('keydown', alTeclear)
  }, [activo, cerrar, contenedor])

  return { activo, abrir, cerrar, ir, porUsuario }
}

type Regla = ReturnType<typeof useReglaActiva>

// Escritorio y tableta: diálogo no modal anclado debajo del tramo (encima si no cabe)
export function TarjetaAnclada({ regla }: { regla: Regla }) {
  const { activo, cerrar, ir, porUsuario } = regla
  const caja = useRef<HTMLDivElement>(null)
  const [pos, setPos] = useState<{ top: number; left: number; lado: 'arriba' | 'abajo'; x: number } | null>(null)

  useLayoutEffect(() => {
    // El lienzo es el padre posicionado de la tarjeta (su ref aún no está asignada en este efecto)
    const cont = caja.current?.parentElement ?? null
    const el = activo === null ? null : tramoEn(cont, activo)
    if (!cont || !el || !caja.current) return
    const colocar = () => {
      const rc = cont.getBoundingClientRect()
      const lineas = el.getClientRects()
      const primera = lineas[0]
      const ultima = lineas[lineas.length - 1]
      const alto = caja.current!.offsetHeight
      const ancho = 360
      const debajo = ultima.bottom - rc.top + 12
      const cabeDebajo = debajo + alto <= rc.height - 16
      const ref = cabeDebajo ? ultima : primera
      const left = Math.min(Math.max(ref.left - rc.left - 24, 16), rc.width - ancho - 16)
      const x = Math.min(Math.max(ref.left - rc.left + Math.min(ref.width / 2, 40) - left, 20), ancho - 20)
      setPos({ top: cabeDebajo ? debajo : primera.top - rc.top - 12 - alto, left, lado: cabeDebajo ? 'arriba' : 'abajo', x })
    }
    colocar()
    const ro = new ResizeObserver(colocar)
    ro.observe(caja.current)
    ro.observe(cont)
    return () => ro.disconnect()
  }, [activo])

  // El foco entra en el título cuando la tarjeta ya está colocada y visible
  const colocada = pos !== null
  useEffect(() => {
    if (activo === null || !colocada || !porUsuario.current) return
    enfocarTitulo(caja.current)
    caja.current?.scrollIntoView({ block: 'nearest' })
  }, [activo, colocada, porUsuario])

  if (activo === null) return null
  return (
    <TarjetaRegla
      ref={caja}
      key={activo}
      modo="anclada"
      ficha={fichaDeTramo(activo)}
      primera={activo === 0}
      ultima={activo === TRAMOS.length - 1}
      pico={pos ? { lado: pos.lado, x: pos.x } : undefined}
      style={{ position: 'absolute', zIndex: 20, top: pos?.top ?? 0, left: pos?.left ?? 0, visibility: pos ? 'visible' : 'hidden' }}
      onCerrar={cerrar}
      onAnterior={() => ir(-1)}
      onSiguiente={() => ir(1)}
    />
  )
}

// Móvil: pantalla de 844 px con la hoja inferior modal (≤ 60 %) y el tramo activo visible encima
export function VistaMovilConHoja({ regla, barra, children }: { regla: Regla; barra?: ReactNode; children: ReactNode }) {
  const { activo, cerrar, ir } = regla
  const scroll = useRef<HTMLDivElement>(null)
  const hoja = useRef<HTMLDivElement>(null)
  const [compacta, setCompacta] = useState(false)

  // El tramo activo queda en la franja superior, por encima del borde de la hoja
  useLayoutEffect(() => {
    const sc = scroll.current
    const el = activo === null ? null : tramoEn(sc, activo)
    if (!sc || !el) return
    sc.scrollTop += el.getBoundingClientRect().top - sc.getBoundingClientRect().top - 120
  }, [activo])

  useEffect(() => {
    if (activo !== null) enfocarTitulo(hoja.current)
  }, [activo])

  // Trampa de foco: Tab y Mayús+Tab circulan dentro de la hoja
  const atrapar = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== 'Tab' || !hoja.current) return
    const f = [...hoja.current.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], summary')].filter((el) => el.checkVisibility())
    const i = f.indexOf(document.activeElement as HTMLElement)
    const sig = e.shiftKey ? (i <= 0 ? f.length - 1 : i - 1) : i === f.length - 1 ? 0 : i + 1
    e.preventDefault()
    f[sig]?.focus()
  }

  const abierta = activo !== null
  return (
    <div data-capa="pantalla-movil" className="relative h-[844px] overflow-hidden">
      <div ref={scroll} inert={abierta} className="h-full overflow-y-auto">
        {children}
      </div>
      {barra && <div inert={abierta}>{barra}</div>}
      {abierta && (
        <>
          <div data-capa="fondo-oscurecido" aria-hidden="true" onClick={cerrar} className="absolute inset-0 z-10 bg-black/40" />
            <TarjetaRegla
              ref={hoja}
              key={activo}
              modo="hoja"
              ficha={fichaDeTramo(activo)}
              primera={activo === 0}
              ultima={activo === TRAMOS.length - 1}
              style={{ position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 20, maxHeight: compacta ? '40%' : '60%' }}
              onKeyDown={atrapar}
              onCerrar={cerrar}
              onAnterior={() => ir(-1)}
              onSiguiente={() => ir(1)}
              asa={
                <button
                  type="button"
                  aria-label="Cambiar tamaño"
                  data-capa="asa"
                  onClick={() => setCompacta((c) => !c)}
                  className="flex h-11 w-full shrink-0 cursor-pointer items-center justify-center"
                >
                  <span aria-hidden="true" className="h-1 w-10 rounded-full bg-ink-2" />
                </button>
              }
            />
        </>
      )}
    </div>
  )
}
