import { AVISO_TEXTO_CORTO, PASTILLAS, type VariantePastilla } from '../datos/pastilla'

type Props = { variante: VariantePastilla; textoCorto?: boolean; compacta?: boolean }

export default function PastillaResultado({ variante, textoCorto = false, compacta = false }: Props) {
  const { etiqueta, frase } = PASTILLAS[variante]
  return (
    <div data-capa="pastilla" role="status" className={`flex flex-col gap-3 rounded-tarjeta bg-card ${compacta ? 'p-5' : 'p-6'}`}>
      <p className={`font-ui font-bold text-ink ${compacta ? 'text-[24px] leading-tight' : 'text-titulo-pantalla'}`}>{etiqueta}</p>
      <p className="font-texto text-cuerpo text-ink">{frase}</p>
      {textoCorto && (
        <p data-capa="aviso-texto-corto" className="border-t border-ink-2/40 pt-3 font-ui text-secundario text-ink">
          {AVISO_TEXTO_CORTO}
        </p>
      )}
    </div>
  )
}
