import { useRef, type KeyboardEvent, type ReactNode } from 'react'
import { RESULTADO } from '../datos/resultadoEjemplo'
import { EspanolCorrecto, Familias, TextoPlegado } from './BloquesResultado'
import Boton from './Boton'
import PieApp from './PieApp'

export type Pestana = 'texto' | 'reglas' | 'datos'

export const PESTANAS: { id: Pestana; nombre: string }[] = [
  { id: 'texto', nombre: 'Texto' },
  { id: 'reglas', nombre: 'Reglas' },
  { id: 'datos', nombre: 'Datos' },
]

// Alto de la barra de pestañas; el contenido deja este hueco más la zona segura
export const ALTO_BARRA = 56

export const idPestana = (p: Pestana) => `pestana-${p}`
export const idPanel = (p: Pestana) => `panel-${p}`

const titulo = 'font-ui text-titulo-tarjeta font-bold'

// Patrón «tabs» de WAI-ARIA APG con activación automática: flechas, Inicio y Fin
export function BarraPestanas({ activa, onCambiar }: { activa: Pestana; onCambiar: (p: Pestana) => void }) {
  const refs = useRef<Record<string, HTMLButtonElement | null>>({})
  const alTeclear = (e: KeyboardEvent<HTMLDivElement>) => {
    const i = PESTANAS.findIndex((p) => p.id === activa)
    const destino = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: PESTANAS.length - 1 }[e.key]
    if (destino === undefined) return
    e.preventDefault()
    const p = PESTANAS[(destino + PESTANAS.length) % PESTANAS.length].id
    onCambiar(p)
    refs.current[p]?.focus()
  }
  return (
    <nav data-capa="barra-pestanas" aria-label="Secciones del resultado" className="absolute inset-x-0 bottom-0 z-[5] border-t border-line bg-bg pb-[env(safe-area-inset-bottom)]">
      <div role="tablist" aria-label="Secciones del resultado" onKeyDown={alTeclear} className="grid grid-cols-3">
        {PESTANAS.map((p) => {
          const sel = p.id === activa
          return (
            <button
              key={p.id}
              ref={(el) => {
                refs.current[p.id] = el
              }}
              type="button"
              role="tab"
              id={idPestana(p.id)}
              aria-selected={sel}
              aria-controls={idPanel(p.id)}
              tabIndex={sel ? 0 : -1}
              onClick={() => onCambiar(p.id)}
              data-capa={`pestana – ${p.nombre}`}
              className={`-mt-px flex cursor-pointer items-center justify-center border-t-[3px] font-ui text-base ${
                sel ? 'border-accent font-bold text-accent' : 'border-transparent text-ink-2'
              }`}
              style={{ height: ALTO_BARRA }}
            >
              {p.nombre}
            </button>
          )
        })}
      </div>
    </nav>
  )
}

export function PanelPestana({ id, activa, children }: { id: Pestana; activa: Pestana; children: ReactNode }) {
  return (
    <div
      role="tabpanel"
      id={idPanel(id)}
      aria-labelledby={idPestana(id)}
      hidden={id !== activa}
      tabIndex={0}
      data-capa={`panel – ${PESTANAS.find((p) => p.id === id)!.nombre}`}
      className="flex flex-col gap-8 focus-visible:outline-offset-4"
    >
      {children}
    </div>
  )
}

export function PanelTexto({ texto }: { texto: ReactNode }) {
  return (
    <>
      <TextoPlegado />
      {texto}
      <div data-capa="acciones" className="flex flex-col gap-3">
        <Boton className="w-full">Descargar informe</Boton>
        <Boton variante="secundario" className="w-full">Analizar otro texto</Boton>
      </div>
      <PieApp />
    </>
  )
}

// Desglose completo: paquete → familia → regla con sus veces y puntos
function DesgloseCompleto() {
  return (
    <section data-capa="desglose" aria-labelledby="t-desglose-m" className="flex flex-col gap-3">
      <h2 id="t-desglose-m" className={titulo}>Desglose</h2>
      <div data-capa="paquete – RadiografIA 0.1.0" className="flex flex-col gap-3 rounded-tarjeta border border-line p-4">
        <h3 className="font-ui text-base font-bold">RadiografIA 0.1.0</h3>
        <ul className="flex flex-col gap-3">
          {RESULTADO.desglose.map((d) => (
            <li key={d.familia} className="flex flex-col gap-1 border-t border-line pt-3 first:border-t-0 first:pt-0">
              <span className="font-ui text-secundario font-bold">{d.familia}</span>
              {d.lineas.length > 0 && (
                <ul className="flex flex-col gap-1 pl-4 font-ui text-secundario text-ink-2">
                  {d.lineas.map((l) => (
                    <li key={l} className="list-disc">{l}</li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}

export function PanelReglas({ ocultas, alternar }: { ocultas: Set<string>; alternar: (id: string) => void }) {
  return (
    <>
      <Familias ocultas={ocultas} alternar={alternar} />
      <DesgloseCompleto />
    </>
  )
}

export function PanelDatos() {
  return (
    <>
      <details open data-capa="detalle" className="rounded-tarjeta border border-line px-4">
        <summary className="flex min-h-[44px] cursor-pointer items-center font-ui text-base font-bold">Ver el detalle</summary>
        <p className="pb-4 font-ui text-secundario text-ink">{RESULTADO.detalleResumen}</p>
      </details>
      <section data-capa="solo-avisos" aria-labelledby="t-avisos-m" className="flex flex-col gap-2">
        <h2 id="t-avisos-m" className="font-ui text-base font-bold">{RESULTADO.soloAvisos.titulo}</h2>
        <ul className="list-disc pl-5 font-ui text-secundario text-ink-2">
          {RESULTADO.soloAvisos.lineas.map((l) => <li key={l}>{l}</li>)}
        </ul>
      </section>
      <p data-capa="no-miradas" className="font-ui text-secundario text-ink-2">{RESULTADO.noMiradas}</p>
      <EspanolCorrecto />
      <PieApp />
    </>
  )
}
