type Props = { compacta?: boolean; enlace?: { texto: string; textoCorto?: string; href: string } }

export default function CabeceraApp({ compacta = false, enlace }: Props) {
  const e = enlace ?? { texto: 'Catálogo de reglas', textoCorto: 'Catálogo', href: '#catalogo' }
  return (
    <header data-capa="cabecera" className="flex items-start justify-between gap-4 border-b border-line">
      <div data-capa="marca" className={compacta ? 'py-3' : 'py-5'}>
        <p className={`font-ui font-bold tracking-tight ${compacta ? 'text-titulo-tarjeta' : 'text-titulo-pantalla'}`}>
          RadiografIA
        </p>
        <p className="font-texto text-secundario italic text-ink-2">A contraluz se nota todo.</p>
      </div>
      <a
        href={e.href}
        data-capa="enlace-catalogo"
        className={`inline-flex min-h-[44px] items-center font-ui text-base font-bold text-accent underline underline-offset-4 ${compacta ? 'mt-3' : 'mt-5'}`}
      >
        {compacta ? (e.textoCorto ?? e.texto) : e.texto}
      </a>
    </header>
  )
}
