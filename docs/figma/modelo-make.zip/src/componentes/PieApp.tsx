export default function PieApp() {
  return (
    <footer data-capa="pie" className="border-t border-line py-5 font-ui text-secundario text-ink-2">
      RadiografIA analiza estilo; no demuestra autoría.
    </footer>
  )
}
