import type { KeyboardEvent, SyntheticEvent } from 'react'
import { CATEGORIAS } from '../datos/categorias'

type Props = { texto: string; familias: string[]; regla?: string; ocultas?: Set<string>; indice?: number; activo?: boolean; onActivar?: (el: HTMLElement) => void }

const cat = (id: string) => CATEGORIAS.find((c) => c.id === id)!

export default function TramoSubrayado({ texto, familias, regla, ocultas, indice, activo, onActivar }: Props) {
  const visibles = familias.filter((f) => !ocultas?.has(f))
  const nombreRegla = regla ?? familias.map((f) => cat(f).nombre).join(' y ')
  const siglas = familias.map((f) => cat(f).sigla).join('')
  const [f1, f2] = visibles
  const marca = f1 ? `subrayado sub-${f1}${f2 ? ` l2-${f2} sub-apilado` : ''}` : undefined
  // Patrón «button» de WAI-ARIA APG: Enter activa en keydown; Espacio activa en keyup (sin desplazar la página)
  const activar = (e: SyntheticEvent<HTMLSpanElement>) => onActivar?.(e.currentTarget)
  const alPulsar = (e: KeyboardEvent<HTMLSpanElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      activar(e)
    } else if (e.key === ' ') e.preventDefault()
  }
  const alSoltar = (e: KeyboardEvent<HTMLSpanElement>) => {
    if (e.key === ' ') {
      e.preventDefault()
      activar(e)
    }
  }
  return (
    <span
      role="button"
      tabIndex={0}
      data-capa={`tramo – ${nombreRegla} (${siglas})`}
      aria-label={`${nombreRegla}: “${texto}”`}
      aria-haspopup={onActivar ? 'dialog' : undefined}
      aria-expanded={onActivar ? !!activo : undefined}
      data-tramo={indice}
      onClick={activar}
      onKeyDown={alPulsar}
      onKeyUp={alSoltar}
      className={`tramo${activo ? ' tramo-activo' : ''}`}
    >
      <span className={marca}>{texto}</span>
      {visibles.length > 0 && (
        <span aria-hidden="true" className="ml-[2px] align-super font-ui text-[11px] font-normal leading-none text-ink-2">
          {visibles.map((f) => cat(f).sigla).join('·')}
        </span>
      )}
    </span>
  )
}
