import { CATEGORIAS } from '../datos/categorias'
import { RESULTADO } from '../datos/resultadoEjemplo'
import Boton from './Boton'
import Sigla from './Sigla'
import TarjetaFamilia from './TarjetaFamilia'

const cat = (id: string) => CATEGORIAS.find((c) => c.id === id)!
const titulo = 'font-ui text-titulo-tarjeta font-bold'
const resumen = 'flex min-h-[44px] cursor-pointer items-center font-ui text-base font-bold'

export function TextoPlegado() {
  return (
    <div data-capa="cuadro-plegado" className="flex flex-col gap-2">
      <div className="flex items-baseline justify-between gap-4">
        <span className="font-ui text-base font-bold">Tu texto</span>
        <button type="button" className="inline-flex min-h-[44px] items-center font-ui text-base font-bold text-accent underline underline-offset-4">
          Editar el texto
        </button>
      </div>
      <p className="line-clamp-3 rounded-tarjeta border border-ink-2 p-4 font-texto text-cuerpo text-ink-2">
        ## Cinco Claves Para Mejorar Tu Productividad En El Trabajo La productividad se ha convertido en uno de los temas más relevantes del mundo laboral. En este artículo exploraremos cinco claves que pueden transformar la forma de trabajar de cualquier empresa…
      </p>
    </div>
  )
}

export function LoQueMasPesa() {
  return (
    <section data-capa="lo-que-mas-pesa" aria-labelledby="t-pesa" className="flex flex-col gap-3">
      <h2 id="t-pesa" className={titulo}>Lo que más pesa</h2>
      <ol className="flex flex-col gap-3">
        {RESULTADO.loQueMasPesa.map((r) => {
          const c = cat(r.familia)
          return (
            <li key={r.nombre} data-capa={`motivo – ${r.nombre} (${c.sigla})`} className="flex flex-col gap-2">
              <div className="flex items-center gap-3 rounded-tarjeta border border-line border-l-4 bg-bg py-3 pl-3 pr-4" style={{ borderLeftColor: c.color }}>
                <Sigla letra={c.sigla} color={c.color} />
                <span className="flex-1 font-ui text-base font-bold">{r.nombre}</span>
                <span className="font-ui text-secundario text-ink-2">{r.cola}</span>
              </div>
              {r.empiezaPor && <p className="font-texto text-secundario italic text-ink">{r.empiezaPor}</p>}
            </li>
          )
        })}
      </ol>
    </section>
  )
}

export function Familias({ ocultas, alternar }: { ocultas: Set<string>; alternar: (id: string) => void }) {
  return (
    <section data-capa="leyenda" aria-labelledby="t-fam" className="flex flex-col gap-3">
      <h2 id="t-fam" className={titulo}>Familias</h2>
      <ul className="grid grid-cols-1 gap-2">
        {RESULTADO.familias.map((f) => (
          <TarjetaFamilia key={f.id} id={f.id} etiqueta={f.etiqueta} oculta={ocultas.has(f.id)} onAlternar={() => alternar(f.id)} />
        ))}
      </ul>
      <ul>
        <TarjetaFamilia id="canal" etiqueta={RESULTADO.canal} oculta={ocultas.has('canal')} onAlternar={() => alternar('canal')} />
      </ul>
    </section>
  )
}

export function Detalle() {
  return (
    <details data-capa="desglose" className="rounded-tarjeta border border-line px-4">
      <summary className={resumen}>Ver el detalle</summary>
      <div className="flex flex-col gap-4 pb-4 font-ui text-secundario text-ink">
        <p>{RESULTADO.detalleResumen}</p>
        <ul className="flex flex-col gap-2">
          {RESULTADO.desglose.map((d) => (
            <li key={d.familia}>
              <span className="font-bold">{d.familia}</span>
              {d.lineas.length > 0 && (
                <ul className="mt-1 list-disc pl-5 text-ink-2">
                  {d.lineas.map((l) => <li key={l}>{l}</li>)}
                </ul>
              )}
            </li>
          ))}
        </ul>
        <div>
          <p className="font-bold">{RESULTADO.soloAvisos.titulo}</p>
          <ul className="mt-1 list-disc pl-5 text-ink-2">
            {RESULTADO.soloAvisos.lineas.map((l) => <li key={l}>{l}</li>)}
          </ul>
        </div>
        <p className="text-ink-2">{RESULTADO.noMiradas}</p>
      </div>
    </details>
  )
}

export function EspanolCorrecto() {
  return (
    <section data-capa="espanol-correcto" aria-labelledby="t-esp" className="flex flex-col gap-2 rounded-tarjeta border border-line p-4">
      <h2 id="t-esp" className="font-ui text-base font-bold">Español correcto</h2>
      <p className="font-ui text-secundario">{RESULTADO.espanolCorrecto.resumen}</p>
      <details>
        <summary className={resumen}>Ver el detalle</summary>
        <ul className="list-disc pl-5 font-ui text-secundario text-ink-2">
          {RESULTADO.espanolCorrecto.lineas.map((l) => <li key={l}>{l}</li>)}
        </ul>
      </details>
    </section>
  )
}

export function AccionesResultado() {
  return (
    <div data-capa="acciones" className="flex flex-wrap gap-3">
      <Boton>Descargar informe</Boton>
      <Boton variante="secundario">Analizar otro texto</Boton>
    </div>
  )
}
