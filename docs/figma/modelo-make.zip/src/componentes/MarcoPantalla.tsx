import type { ReactNode } from 'react'

export type Tamano = 'escritorio' | 'tableta' | 'movil'

export const ANCHOS: Record<Tamano, number> = { escritorio: 1280, tableta: 820, movil: 390 }
export const NOMBRES_TAMANO: Record<Tamano, string> = {
  escritorio: 'Escritorio',
  tableta: 'Tableta',
  movil: 'Móvil',
}

type Props = { pantalla: string; tamano: Tamano; nombreTamano?: string; children: ReactNode }

export default function MarcoPantalla({ pantalla, tamano, nombreTamano, children }: Props) {
  const nombre = `Pantalla / ${pantalla} / ${nombreTamano ?? NOMBRES_TAMANO[tamano]}`
  return (
    <div
      data-capa={nombre}
      aria-label={nombre}
      className="relative mx-auto min-h-[640px] bg-bg text-ink shadow-suave"
      style={{ width: ANCHOS[tamano] }}
    >
      {children}
    </div>
  )
}
