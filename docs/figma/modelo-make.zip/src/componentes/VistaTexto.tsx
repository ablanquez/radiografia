import { ANCLAS, TEXTO_EJEMPLO, TRAMOS } from '../datos/resultadoEjemplo'
import TramoSubrayado from './TramoSubrayado'

export type Pieza = string | { i: number }

// Trocea el texto en orden según los tramos
function trocear(): Pieza[][] {
  const piezas: Pieza[] = []
  let pos = 0
  TRAMOS.forEach((t, i) => {
    const desde = ANCLAS[i] ? TEXTO_EJEMPLO.indexOf(ANCLAS[i], pos) + ANCLAS[i].length : pos
    const at = TEXTO_EJEMPLO.indexOf(t.texto, desde)
    if (at > pos) piezas.push(TEXTO_EJEMPLO.slice(pos, at))
    piezas.push({ i })
    pos = at + t.texto.length
  })
  piezas.push(TEXTO_EJEMPLO.slice(pos))
  const parrafos: Pieza[][] = [[]]
  piezas.forEach((p) => {
    if (typeof p !== 'string') return parrafos[parrafos.length - 1].push(p)
    p.split('\n').forEach((trozo, k) => {
      if (k > 0) parrafos.push([])
      if (trozo) parrafos[parrafos.length - 1].push(trozo)
    })
  })
  return parrafos
}

export const PARRAFOS = trocear()

type Props = { ocultas: Set<string>; activo?: number | null; onActivar?: (i: number, el: HTMLElement) => void }

export default function VistaTexto({ ocultas, activo, onActivar }: Props) {
  return (
    <article data-capa="vista-texto" aria-label="Tu texto analizado" className="flex max-w-columna-texto flex-col gap-4 font-texto text-cuerpo text-ink">
      {PARRAFOS.map((pzs, n) => (
        <p key={n} data-capa={`párrafo ${n + 1}`}>
          {pzs.map((p, k) => (typeof p === 'string' ? p : (
              <TramoSubrayado
                key={k}
                {...TRAMOS[p.i]}
                ocultas={ocultas}
                indice={p.i}
                activo={activo === p.i}
                onActivar={onActivar && ((el) => onActivar(p.i, el))}
              />
            )))}
        </p>
      ))}
    </article>
  )
}
