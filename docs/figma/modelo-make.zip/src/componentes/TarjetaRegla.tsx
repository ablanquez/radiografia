import { forwardRef, useId, type CSSProperties, type KeyboardEventHandler, type ReactNode } from 'react'
import { CATEGORIAS } from '../datos/categorias'
import type { Ficha } from '../datos/reglas'
import Boton from './Boton'
import Sigla from './Sigla'

type Props = {
  ficha: Ficha
  modo: 'anclada' | 'hoja' | 'estatica'
  primera?: boolean
  ultima?: boolean
  porQueAbierto?: boolean
  pico?: { lado: 'arriba' | 'abajo'; x: number }
  style?: CSSProperties
  idTitulo?: string
  onCerrar?: () => void
  onAnterior?: () => void
  onSiguiente?: () => void
  asa?: ReactNode
  onKeyDown?: KeyboardEventHandler<HTMLDivElement>
}

// Los textos entre corchetes son relleno pendiente: se marcan para que no pasen por definitivos
function Texto({ children }: { children: string }) {
  return children.startsWith('[') ? (
    <span data-capa="relleno" className="italic text-ink-2">{children}</span>
  ) : (
    <>{children}</>
  )
}

function IconoCerrar() {
  return (
    <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M5 5l10 10M15 5L5 15" />
    </svg>
  )
}

const TarjetaRegla = forwardRef<HTMLDivElement, Props>(function TarjetaRegla(
  { ficha, modo, primera, ultima, porQueAbierto, pico, style, idTitulo, onCerrar, onAnterior, onSiguiente, asa, onKeyDown },
  ref,
) {
  const idPropio = useId()
  const idT = idTitulo ?? `${idPropio}-titulo`
  const c = ficha.familia ? CATEGORIAS.find((x) => x.id === ficha.familia) : undefined
  const color = c?.color ?? 'var(--color-ink-2)'
  const hoja = modo === 'hoja'

  return (
    <div
      ref={ref}
      role="dialog"
      aria-modal={hoja ? true : undefined}
      aria-labelledby={idT}
      data-capa={hoja ? 'hoja-inferior' : 'tarjeta-regla'}
      style={style}
      onKeyDown={onKeyDown}
      className={
        hoja
          ? 'flex flex-col rounded-t-tarjeta border-t border-line bg-bg font-ui text-ink'
          : 'relative w-[360px] rounded-tarjeta border border-line bg-bg font-ui text-ink shadow-suave'
      }
    >
      {pico && (
        <span
          aria-hidden="true"
          data-capa="pico"
          className={`absolute size-3 rotate-45 border-line ${pico.lado === 'arriba' ? '-top-[6px] border-l border-t' : '-bottom-[6px] border-b border-r bg-bg'}`}
          style={{ left: pico.x - 6, ...(pico.lado === 'arriba' ? { background: color, borderColor: color } : {}) }}
        />
      )}
      <div data-capa="barra-familia" className={`relative h-1.5 ${hoja ? '' : 'rounded-t-[7px]'}`} style={{ background: color }} />
      {asa}

      <div className={`flex min-h-0 flex-col gap-4 ${hoja ? 'overflow-y-auto px-4 pb-4' : 'px-5 pb-5 pt-4'}`}>
        <div data-capa="cabecera-tarjeta" className="flex items-start gap-3">
          {c && (
            <span className="mt-2.5">
              <Sigla letra={c.sigla} color={c.color} />
            </span>
          )}
          <div className="flex min-w-0 flex-1 flex-col gap-0.5 pt-2">
            <h2 id={idT} tabIndex={-1} className="font-ui text-titulo-tarjeta font-bold">
              {ficha.titulo}
            </h2>
            <p className="text-secundario text-ink-2">{ficha.linea}</p>
          </div>
          <button
            type="button"
            aria-label="Cerrar"
            data-capa="boton-cerrar"
            onClick={onCerrar}
            className="-mr-2 inline-flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-boton text-ink hover:bg-card"
          >
            <IconoCerrar />
          </button>
        </div>

        <p className="text-base">
          <Texto>{ficha.frase}</Texto>
        </p>
        <p className="text-base">
          <span className="font-bold">Qué hacer: </span>
          <Texto>{ficha.queHacer}</Texto>
        </p>

        <details data-capa="por-que" open={porQueAbierto} className="border-t border-line">
          <summary className="flex min-h-[44px] cursor-pointer items-center font-bold">¿Por qué lo miramos?</summary>
          <div className="flex flex-col gap-2 pb-1 text-secundario">
            {ficha.porQue && (
              <p>
                <Texto>{ficha.porQue}</Texto>
              </p>
            )}
            <dl className="flex flex-col gap-1">
              <div>
                <dt className="inline font-bold">Nivel de evidencia: </dt>
                <dd className="inline"><Texto>{ficha.evidencia}</Texto></dd>
              </div>
              {ficha.origen && (
                <div>
                  <dt className="inline font-bold">Origen de la lista: </dt>
                  <dd className="inline"><Texto>{ficha.origen}</Texto></dd>
                </div>
              )}
              {ficha.paquete && (
                <div>
                  <dt className="inline font-bold">Paquete: </dt>
                  <dd className="inline">{ficha.paquete}</dd>
                </div>
              )}
            </dl>
            {ficha.enlace && (
              <a href="#catalogo" className="inline-flex min-h-[44px] items-center self-start font-bold text-accent underline underline-offset-4">
                Ver la ficha completa
              </a>
            )}
            {ficha.nota && <p className="text-ink-2">{ficha.nota}</p>}
          </div>
        </details>

        <div data-capa="navegacion-reglas" className={`flex gap-3 ${hoja ? 'flex-col' : ''}`}>
          <Boton variante="secundario" disabled={primera} onClick={onAnterior} className={`flex-1 ${primera ? 'cursor-not-allowed border-line text-ink-2 hover:bg-bg' : 'cursor-pointer'}`}>
            Anterior
          </Boton>
          <Boton variante="secundario" disabled={ultima} onClick={onSiguiente} className={`flex-1 ${ultima ? 'cursor-not-allowed border-line text-ink-2 hover:bg-bg' : 'cursor-pointer'}`}>
            Siguiente
          </Boton>
        </div>
      </div>
    </div>
  )
})

export default TarjetaRegla
