type Props = { id: string; etiqueta: string; oculta: boolean; onAlternar: () => void }

function Ojo({ tachado }: { tachado: boolean }) {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z" />
      <circle cx="12" cy="12" r="3" />
      {tachado && <path d="M4 4l16 16" />}
    </svg>
  )
}

export default function TarjetaFamilia({ id, etiqueta, oculta, onAlternar }: Props) {
  return (
    <li data-capa={`tarjeta-familia – ${etiqueta}`} className="flex items-center gap-2 rounded-tarjeta border border-line bg-bg py-1 pl-3 pr-0">
      <span aria-hidden="true" className={`font-texto text-cuerpo ${oculta ? 'text-ink-2' : `subrayado sub-${id}`}`}>
        Abc
      </span>
      <span className={`flex-1 font-ui text-secundario ${oculta ? 'text-ink-2' : 'text-ink'}`}>{etiqueta}</span>
      <button
        type="button"
        aria-pressed={oculta}
        aria-label={`${oculta ? 'Mostrar esta capa' : 'Ocultar esta capa'}: ${etiqueta}`}
        title={oculta ? 'Mostrar esta capa' : 'Ocultar esta capa'}
        onClick={onAlternar}
        className="inline-flex size-[44px] shrink-0 items-center justify-center rounded-boton text-ink-2 hover:bg-card"
      >
        <Ojo tachado={oculta} />
      </button>
    </li>
  )
}
