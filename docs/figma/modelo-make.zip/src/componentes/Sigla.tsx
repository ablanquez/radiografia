type Props = { letra: string; color: string }

export default function Sigla({ letra, color }: Props) {
  return (
    <span
      data-capa={`sigla-${letra}`}
      aria-hidden="true"
      className="inline-flex size-6 shrink-0 items-center justify-center rounded-full border-2 bg-bg font-ui text-[13px] font-bold leading-none text-ink"
      style={{ borderColor: color }}
    >
      {letra}
    </span>
  )
}
