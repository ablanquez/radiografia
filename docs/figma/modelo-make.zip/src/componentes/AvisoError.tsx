import type { ReactNode } from 'react'

type Props = { children: ReactNode; detalles?: string[] }

export default function AvisoError({ children, detalles = [] }: Props) {
  return (
    <div
      role="alert"
      data-capa="aviso-error"
      className="flex gap-3 rounded-tarjeta border border-ink-2 bg-aviso-error p-4 font-ui text-base text-ink"
    >
      <svg aria-hidden="true" viewBox="0 0 24 24" className="mt-0.5 size-5 shrink-0" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="12" r="10" />
        <path d="M12 7v6M12 16.5v.5" strokeLinecap="round" />
      </svg>
      <div className="flex flex-col gap-2">
        <p>
          <strong>Error</strong> · {children}
        </p>
        {detalles.length > 0 && (
          <ul data-capa="lista-fallos" className="list-disc pl-5 text-secundario">
            {detalles.map((d) => (
              <li key={d}>{d}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
