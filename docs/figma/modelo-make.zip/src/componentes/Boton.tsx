import type { ComponentProps } from 'react'

type Props = ComponentProps<'button'> & { variante?: 'principal' | 'secundario' }

export default function Boton({ variante = 'principal', className = '', ...resto }: Props) {
  const estilo =
    variante === 'principal'
      ? 'bg-accent text-white border-accent'
      : 'bg-bg text-ink border-ink-2 hover:bg-card'
  return (
    <button
      type="button"
      data-capa={`boton-${variante}`}
      className={`inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-boton border px-5 font-ui text-base font-bold ${estilo} ${className}`}
      {...resto}
    />
  )
}
