import Boton from './Boton'
import AvisoError from './AvisoError'

export type EstadoFormulario = 'vacio' | 'insuficiente' | 'error-paquete'

const TIPOS = ['General', 'Académico', 'Administrativo', 'Narrativa clásica', 'Noticia', 'Opinión (críticas de cine)']

type Props = { movil?: boolean; estado?: EstadoFormulario; paquetesAbiertos?: boolean }

function Paquetes({ abierto, estado }: { abierto: boolean; estado: EstadoFormulario }) {
  return (
    <details data-capa="paquetes" open={abierto} className="rounded-tarjeta border border-line bg-card">
      <summary className="flex min-h-[44px] cursor-pointer items-center px-4 font-ui text-base font-bold">Paquetes</summary>
      <div className="flex flex-col gap-3 px-4 pb-4">
        {['RadiografIA 0.1.0', 'Español correcto 0.1.0'].map((p) => (
          <label key={p} data-capa={`casilla – ${p}`} className="flex min-h-[44px] items-center gap-3 font-ui text-base">
            <input type="checkbox" defaultChecked className="size-5 accent-accent" />
            {p}
          </label>
        ))}
        <div>
          <Boton variante="secundario">Cargar un paquete propio (JSON)</Boton>
        </div>
        {estado === 'error-paquete' && (
          <AvisoError detalles={['regla "prueba-a-nivel-de" (reglas[0]) · campo "peso": tiene que ser número']}>
            No se carga «mi-paquete.json»: no cumple el esquema de los paquetes. Esto es lo que falla:
          </AvisoError>
        )}
        <p className="font-ui text-secundario text-ink-2">
          Se queda en tu navegador: no se sube a ningún sitio. No se guarda: al recargar la página, desaparece.
        </p>
      </div>
    </details>
  )
}

export default function FormularioAnalisis({ movil = false, estado = 'vacio', paquetesAbiertos = false }: Props) {
  const abierto = paquetesAbiertos || estado === 'error-paquete'
  const botones = (
    <div data-capa="acciones" className={movil ? 'flex flex-col gap-3' : 'flex flex-wrap gap-4'}>
      <Boton className={movil ? 'min-h-[48px] w-full' : ''}>Pon tu texto a contraluz</Boton>
      <Boton variante="secundario" disabled className={`cursor-not-allowed border-line text-ink-2 hover:bg-bg ${movil ? 'w-full' : ''}`}>
        Descargar informe
      </Boton>
    </div>
  )

  return (
    <form data-capa="formulario-analisis" className="flex flex-col gap-6" onSubmit={(e) => e.preventDefault()}>
      <div data-capa="campo-texto" className="flex flex-col gap-2">
        <label htmlFor="tu-texto" className="font-ui text-base font-bold">Tu texto</label>
        <textarea
          id="tu-texto"
          rows={12}
          aria-describedby={estado === 'insuficiente' ? 'aviso-insuficiente' : undefined}
          placeholder="Pega aquí tu texto: a partir de 100 palabras; el análisis es completo desde 300"
          className="w-full resize-y rounded-tarjeta border border-ink-2 bg-bg p-4 font-texto text-cuerpo placeholder:text-ink-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
        />
        {estado === 'insuficiente' && (
          <p id="aviso-insuficiente" data-capa="aviso-insuficiente" className="flex items-center gap-2 font-ui text-secundario text-ink">
            <svg aria-hidden="true" viewBox="0 0 24 24" className="size-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <path d="M12 7v6M12 16.5v.5" strokeLinecap="round" />
            </svg>
            Texto insuficiente: 99 palabras que cuentan; se puntúa desde 100
          </p>
        )}
      </div>

      <div data-capa="ejemplos" className="flex flex-col gap-2">
        <div className="flex flex-wrap gap-3">
          {['Texto humano', 'Texto de IA'].map((c) => (
            <button
              key={c}
              type="button"
              data-capa={`chip – ${c}`}
              className="inline-flex min-h-[44px] items-center rounded-full border border-ink-2 bg-bg px-5 font-ui text-base hover:bg-card"
            >
              {c}
            </button>
          ))}
        </div>
        <p className="font-ui text-secundario text-ink-2">
          Ejemplos: el primero lo escribió Antonio; el segundo lo generó un asistente sin instrucciones de estilo
        </p>
      </div>

      <div data-capa="tipo-texto" className="flex flex-col gap-2">
        <label htmlFor="tipo-texto" className="font-ui text-base font-bold">Tipo de texto</label>
        <select
          id="tipo-texto"
          className={`min-h-[44px] rounded-boton border border-ink-2 bg-bg px-3 font-ui text-base ${movil ? 'w-full' : 'w-80'}`}
        >
          {TIPOS.map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
      </div>

      {movil ? (
        <>
          {botones}
          <Paquetes abierto={abierto} estado={estado} />
        </>
      ) : (
        <>
          <Paquetes abierto={abierto} estado={estado} />
          {botones}
        </>
      )}
    </form>
  )
}
