import { useEffect, useState, type ComponentType } from 'react'
import { ANCHOS, NOMBRES_TAMANO, type Tamano } from './componentes/MarcoPantalla'
import Catalogo, { CatalogoFiltros, CatalogoSinResultados } from './pantallas/Catalogo'
import FichaRegla from './pantallas/FichaRegla'
import IconoVariantes from './pantallas/Icono'
import Informe from './pantallas/Informe'
import Muestrario from './pantallas/Muestrario'
import AnalizadorResultado, { AnalizadorResultadoDatos, AnalizadorResultadoReglas, PastillaVariantes } from './pantallas/AnalizadorResultado'
import TarjetaReglaPantalla, { TarjetaReglaEstados } from './pantallas/TarjetaReglaPantalla'
import AnalizadorVacio, { AnalizadorVacioEstados } from './pantallas/AnalizadorVacio'

// Registro de pantallas: se irán añadiendo una a una
const PANTALLAS: { id: string; nombre: string; componente: ComponentType<{ tamano: Tamano }>; tamanos: Tamano[] }[] = [
  { id: 'analizador-vacio', nombre: 'Analizador vacío', componente: AnalizadorVacio, tamanos: ['escritorio', 'tableta', 'movil'] },
  { id: 'analizador-vacio-estados', nombre: 'Analizador vacío · Estados', componente: AnalizadorVacioEstados, tamanos: ['escritorio'] },
  { id: 'analizador-resultado', nombre: 'Analizador con resultado', componente: AnalizadorResultado, tamanos: ['escritorio', 'tableta', 'movil'] },
  { id: 'analizador-resultado-reglas', nombre: 'Analizador con resultado · Reglas', componente: AnalizadorResultadoReglas, tamanos: ['movil'] },
  { id: 'analizador-resultado-datos', nombre: 'Analizador con resultado · Datos', componente: AnalizadorResultadoDatos, tamanos: ['movil'] },
  { id: 'tarjeta-regla', nombre: 'Tarjeta de regla', componente: TarjetaReglaPantalla, tamanos: ['escritorio', 'tableta', 'movil'] },
  { id: 'tarjeta-regla-estados', nombre: 'Tarjeta de regla · Estados', componente: TarjetaReglaEstados, tamanos: ['escritorio'] },
  { id: 'catalogo', nombre: 'Catálogo de reglas', componente: Catalogo, tamanos: ['escritorio', 'tableta', 'movil'] },
  { id: 'catalogo-sin-resultados', nombre: 'Catálogo · Sin resultados', componente: CatalogoSinResultados, tamanos: ['escritorio'] },
  { id: 'catalogo-filtros', nombre: 'Catálogo · Filtros', componente: CatalogoFiltros, tamanos: ['movil'] },
  { id: 'ficha-regla', nombre: 'Ficha de regla', componente: FichaRegla, tamanos: ['escritorio', 'tableta', 'movil'] },
  { id: 'informe', nombre: 'Informe', componente: Informe, tamanos: ['escritorio'] },
  { id: 'icono', nombre: 'Icono · Variantes', componente: IconoVariantes, tamanos: ['escritorio'] },
  { id: 'pastilla-variantes', nombre: 'Pastilla · Variantes', componente: PastillaVariantes, tamanos: ['escritorio'] },
  { id: 'muestrario', nombre: 'Muestrario', componente: Muestrario, tamanos: ['escritorio', 'tableta', 'movil'] },
]

function leerHash() {
  const [id, tam] = window.location.hash.replace('#', '').split('/')
  const p = PANTALLAS.find((x) => x.id === id) ?? PANTALLAS[0]
  const t = (p.tamanos.includes(tam as Tamano) ? tam : p.tamanos[0]) as Tamano
  return { p, t }
}

export default function App() {
  const [estado, setEstado] = useState(leerHash)
  useEffect(() => {
    const f = () => setEstado(leerHash())
    window.addEventListener('hashchange', f)
    return () => window.removeEventListener('hashchange', f)
  }, [])
  const { p, t } = estado
  const Pantalla = p.componente

  return (
    <div className="min-h-screen bg-card">
      <nav aria-label="Selector de marcos" className="flex flex-wrap gap-x-6 gap-y-2 border-b border-line bg-bg px-4 py-2 font-ui text-secundario">
        {PANTALLAS.map((x) => (
          <div key={x.id} className="flex items-center gap-1">
            <span className="mr-1 font-bold">{x.nombre}</span>
            {x.tamanos.map((tm) => {
              const activo = x.id === p.id && tm === t
              return (
                <a
                  key={tm}
                  href={`#${x.id}/${tm}`}
                  aria-current={activo ? 'page' : undefined}
                  className={`inline-flex min-h-[44px] items-center rounded-boton px-3 ${activo ? 'bg-accent text-white' : 'text-ink hover:bg-card'}`}
                >
                  {x.id === 'informe' ? 'A4 · 794' : `${NOMBRES_TAMANO[tm]} · ${ANCHOS[tm]}`}
                </a>
              )
            })}
          </div>
        ))}
      </nav>
      <div className="overflow-x-auto py-8">
        <Pantalla tamano={t} />
      </div>
    </div>
  )
}
