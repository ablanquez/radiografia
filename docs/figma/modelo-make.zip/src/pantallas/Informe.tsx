import { Fragment, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { PARRAFOS } from '../componentes/VistaTexto'
import { CATEGORIAS } from '../datos/categorias'
import { FICHA_CONECTOR } from '../datos/reglas'
import { RESULTADO, TRAMOS } from '../datos/resultadoEjemplo'

// A4 a 96 dpi: 210 × 297 mm → 794 × 1123 px; márgenes 20 mm arriba y abajo, 18 mm a los lados
const MM = 96 / 25.4
const ANCHO = Math.round(210 * MM)
const ALTO = Math.round(297 * MM)
const M_V = 20 * MM
const M_H = 18 * MM
const UTIL = ALTO - 2 * M_V
const RESERVA_SALTO = 32 // hueco para la marca «salto de página»
const PT = 96 / 72

const tituloSeccion = 'font-ui font-bold leading-tight mb-[0.6em]'
const relleno = 'italic text-ink-2'

function Titulo({ n, children }: { n: number; children: string }) {
  return (
    <h2 className={tituloSeccion} style={{ fontSize: 14 * PT }}>
      {n}. {children}
    </h2>
  )
}

const sigla = (familias: string[]) => familias.map((f) => CATEGORIAS.find((c) => c.id === f)!.sigla).join('·')

// Muestra en tinta del estilo de línea de cada familia
function MuestraTinta({ id }: { id: string }) {
  const p = { stroke: '#1a1a1a', fill: 'none' }
  const formas: Record<string, ReactNode> = {
    lexico: <line x1="0" y1="5" x2="32" y2="5" {...p} strokeWidth="2" />,
    discurso: <line x1="0" y1="5" x2="32" y2="5" {...p} strokeWidth="3" />,
    sintaxis: <line x1="0" y1="5" x2="32" y2="5" {...p} strokeWidth="2" strokeDasharray="6 4" />,
    estadistica: <path d="M0 3.5H32M0 6.5H32" {...p} strokeWidth="1" />,
    puntuacion: <line x1="1.5" y1="5" x2="32" y2="5" {...p} strokeWidth="3" strokeLinecap="round" strokeDasharray="0 6" />,
    canal: <line x1="0" y1="5" x2="32" y2="5" {...p} strokeWidth="1" strokeDasharray="1 2" />,
    gramatica: <path d="M0 5Q2 3 4 5T8 5T12 5T16 5T20 5T24 5T28 5T32 5" {...p} strokeWidth="1.5" />,
    ortotipografia: <path d="M0 3H32M0 7H32" {...p} strokeWidth="1" strokeDasharray="4 3" />,
  }
  return (
    <svg aria-hidden="true" width="32" height="10" viewBox="0 0 32 10" className="shrink-0">
      {formas[id]}
    </svg>
  )
}

const CLAVE = [
  ['lexico', '[L] Léxico (RadiografIA)'],
  ['discurso', '[D] Discurso (RadiografIA)'],
  ['sintaxis', '[S] Sintaxis (RadiografIA)'],
  ['estadistica', '[E] Estadística (RadiografIA)'],
  ['puntuacion', '[P] Puntuación y formato (RadiografIA)'],
  ['canal', '[C] Canal (RadiografIA) · solo avisos'],
  ['gramatica', '[G] Gramática (Español correcto)'],
  ['ortotipografia', '[O] Ortotipografía (Español correcto)'],
]

type Entrada = { nombre: string; id?: string; frase: string; fragmentos: string[]; queHacer: string }

// PENDIENTE: solo «Conector repetido» tiene id, frase y consejo reales; el resto lleva relleno
const ENTRADAS: Entrada[] = [
  { nombre: 'Conector repetido', id: 'disc-marcador-repetido', frase: FICHA_CONECTOR.frase, fragmentos: ['Además', 'Además', 'Además'], queHacer: FICHA_CONECTOR.queHacer },
  { nombre: 'Coletilla de gerundio final', frase: '[Descripción de la regla: una frase.]', fragmentos: [', mejorando la concentración de todo el equipo.', ', permitiendo centrarse en las tareas importantes.'], queHacer: '[Consejo de la ficha.]' },
  { nombre: 'Atribución vaga', frase: '[Descripción de la regla: una frase.]', fragmentos: ['Los expertos coinciden', 'Diversos estudios demuestran'], queHacer: '[Consejo de la ficha.]' },
  { nombre: 'Cierre de plantilla', frase: '[Descripción de la regla: una frase.]', fragmentos: ['En conclusión'], queHacer: '[Consejo de la ficha.]' },
]

const T = ({ children }: { children: string }) => (children.startsWith('[') ? <span data-capa="relleno" className={relleno}>{children}</span> : <>{children}</>)

function FichaEntrada({ e }: { e: Entrada }) {
  return (
    <article data-capa={`entrada – ${e.nombre}`} className="entrada flex flex-col gap-[0.3em]">
      <p>
        <strong className="font-bold">{e.nombre}</strong>{' '}
        <span className="break-all font-ui text-ink-2" style={{ fontSize: 9.5 * PT }}>
          (https://radiografia.example/reglas/{e.id ?? <span data-capa="relleno" className="italic">[id]</span>}/)
        </span>
      </p>
      <p><T>{e.frase}</T></p>
      <p>Fragmentos: {e.fragmentos.map((f) => `«${f}»`).join(', ')}</p>
      <p><span className="font-bold">Qué hacer: </span><T>{e.queHacer}</T></p>
    </article>
  )
}

type Bloque = { clave: string; nodo: ReactNode; salto?: boolean }

const BLOQUES: Bloque[] = [
  {
    clave: 's1',
    nodo: (
      <section data-capa="seccion 1 – Informe de RadiografIA">
        <h1 className={tituloSeccion} style={{ fontSize: 14 * PT }}>1. Informe de RadiografIA</h1>
        <div className="flex flex-col gap-[0.25em]">
          <p>Análisis del 3 de octubre de 2026 a las 20:44</p>
          <p>325 palabras que cuentan (sin listas, títulos, tablas ni código) · textos de 300 a 599 palabras · tipo: General</p>
          <p>Paquetes: RadiografIA 0.1.0 · Español correcto 0.1.0</p>
          <p>Tu total: 44,08 puntos por cada 1.000 palabras.</p>
          <p>Comparado con 500 textos de 300 a 599 palabras escritos por personas: mediana 1,86 · p95 32,17 · p99 57,24.</p>
        </div>
      </section>
    ),
  },
  {
    clave: 's2',
    nodo: (
      <section data-capa="seccion 2 – Resultado">
        <Titulo n={2}>Resultado</Titulo>
        <div className="flex flex-col gap-[0.4em]">
          <p className="font-ui font-bold leading-snug" style={{ fontSize: 16 * PT }}>Texto con bastantes rasgos de Asistente IA</p>
          <p>Tu texto suena bastante a asistente (IA): de cada 100 textos escritos por personas, solo 5 suenan tanto.</p>
          <p>Lo que más pesa: Conector repetido (3 veces) · Coletilla de gerundio final (2 veces) · Atribución vaga (2 veces).</p>
          <p>Empieza por: Cambia alguno de los conectores repetidos o quítalo: muchas veces la frase se entiende sin él.</p>
          <p>Español correcto: 9 avisos de norma: Mes o día con mayúscula (3) y Pasiva perifrástica con agente (1).</p>
        </div>
      </section>
    ),
  },
  {
    clave: 's3',
    nodo: (
      <section data-capa="seccion 3 – Clave de familias">
        <Titulo n={3}>Clave de familias</Titulo>
        <ul className="flex flex-col gap-[0.2em]">
          {CLAVE.map(([id, txt]) => (
            <li key={id} className="flex items-center gap-3">
              <MuestraTinta id={id} />
              <span>{txt}</span>
            </li>
          ))}
        </ul>
      </section>
    ),
  },
  ...PARRAFOS.map((pzs, n) => {
    const p = (
      <p data-capa={`párrafo ${n + 1}`}>
        {pzs.map((pz, k) => {
          if (typeof pz === 'string') return <Fragment key={k}>{pz}</Fragment>
          const t = TRAMOS[pz.i]
          const [f1, f2] = t.familias
          return (
            <Fragment key={k}>
              <span data-capa={`tramo – ${t.regla ?? sigla(t.familias)}`} className={`subrayado sub-${f1} rounded-[2px] px-[2px] ${f2 ? `l2-${f2} sub-apilado` : ''}`}>{t.texto}</span>
              {' '}<span className="font-ui" style={{ fontSize: 9 * PT }}>[{sigla(t.familias)}]</span>
            </Fragment>
          )
        })}
      </p>
    )
    // El título de la sección va unido al primer párrafo
    return n === 0
      ? { clave: 's4', salto: true, nodo: <section data-capa="seccion 4 – Texto"><Titulo n={4}>Texto</Titulo>{p}</section> }
      : { clave: `s4-${n}`, nodo: p }
  }),
  {
    clave: 's5',
    nodo: (
      <section data-capa="seccion 5 – Desglose">
        <Titulo n={5}>Desglose</Titulo>
        <h3 className="font-ui font-bold" style={{ fontSize: 11 * PT }}>RadiografIA 0.1.0</h3>
        <ul className="mt-[0.3em] flex flex-col gap-[0.3em] pl-[1.2em]">
          {RESULTADO.desglose.map((d) => (
            <li key={d.familia} className="list-disc">
              <span className="font-bold">{d.familia}</span>
              {d.lineas.length > 0 && (
                <ul className="pl-[1.2em]">
                  {d.lineas.map((l) => <li key={l} className="list-[circle]">{l}</li>)}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </section>
    ),
  },
  { clave: 's6', salto: true, nodo: <section data-capa="seccion 6 – Las señales, regla a regla"><Titulo n={6}>Las señales, regla a regla</Titulo><FichaEntrada e={ENTRADAS[0]} /></section> },
  ...ENTRADAS.slice(1, -1).map((e) => ({ clave: e.nombre, nodo: <FichaEntrada e={e} /> })),
  // La última entrada y el pie forman un bloque: el pie nunca queda solo en una página
  {
    clave: 'final',
    nodo: (
      <div className="entrada flex flex-col gap-[1.2em]">
        <FichaEntrada e={ENTRADAS[3]} />
        <p data-capa="relleno" className={relleno}>[… 12 entradas más con el mismo formato]</p>
        <footer data-capa="seccion 7 – Pie" className="border-t border-ink pt-[0.6em] font-ui" style={{ fontSize: 10 * PT }}>
          7. RadiografIA analiza estilo; no demuestra autoría.
        </footer>
      </div>
    ),
  },
]

const HUECO = 14 * PT // separación entre bloques

// Reparte los bloques en páginas midiendo su alto real
function paginar(altos: number[]): { bloques: number[]; salto: boolean }[] {
  const paginas: { bloques: number[]; salto: boolean }[] = [{ bloques: [], salto: false }]
  let usado = 0
  BLOQUES.forEach((b, i) => {
    const actual = paginas[paginas.length - 1]
    const extra = (actual.bloques.length ? HUECO : 0) + altos[i]
    const siguienteSalta = BLOQUES[i + 1]?.salto
    const limite = UTIL - (siguienteSalta ? RESERVA_SALTO : 0)
    if (b.salto && actual.bloques.length) {
      actual.salto = true
      paginas.push({ bloques: [i], salto: false })
      usado = altos[i]
    } else if (actual.bloques.length && usado + extra > limite) {
      paginas.push({ bloques: [i], salto: false })
      usado = altos[i]
    } else {
      actual.bloques.push(i)
      usado += extra
    }
  })
  return paginas
}

const tipografia = { fontSize: 11 * PT, lineHeight: 1.45 }

export default function Informe() {
  const medidor = useRef<HTMLDivElement>(null)
  const [paginas, setPaginas] = useState<ReturnType<typeof paginar> | null>(null)

  useLayoutEffect(() => {
    const medir = () => {
      const hijos = [...(medidor.current?.children ?? [])] as HTMLElement[]
      setPaginas(paginar(hijos.map((h) => h.getBoundingClientRect().height)))
    }
    medir()
    document.fonts?.ready.then(medir)
  }, [])

  const nombre = 'Pantalla / Informe / A4'
  return (
    <div data-capa={nombre} aria-label={nombre} className="informe-a4 mx-auto flex flex-col gap-8 font-texto text-ink" style={{ width: ANCHO }}>
      {/* Columna invisible para medir los bloques al ancho útil */}
      <div ref={medidor} aria-hidden="true" className="invisible absolute" style={{ width: ANCHO - 2 * M_H, ...tipografia }}>
        {BLOQUES.map((b) => <div key={b.clave}>{b.nodo}</div>)}
      </div>
      {paginas?.map((pg, n) => (
        <div
          key={n}
          data-capa={`página ${n + 1}`}
          className="relative flex flex-col bg-bg shadow-suave"
          style={{ width: ANCHO, height: ALTO, padding: `${M_V}px ${M_H}px`, ...tipografia }}
        >
          <div className="flex flex-col" style={{ gap: HUECO }}>
            {pg.bloques.map((i) => (
              <div key={BLOQUES[i].clave} className={BLOQUES[i].salto ? 'salto-antes' : undefined}>{BLOQUES[i].nodo}</div>
            ))}
          </div>
          {pg.salto && (
            <div data-capa="salto de página" aria-hidden="true" className="mt-auto flex items-center gap-3 font-ui text-ink-2" style={{ fontSize: 9 * PT }}>
              <span className="flex-1 border-t border-dashed border-ink-2" />
              salto de página
              <span className="flex-1 border-t border-dashed border-ink-2" />
            </div>
          )}
          <p data-capa="número de página" className="absolute font-ui text-ink-2" style={{ right: M_H, bottom: M_V / 2 - 6, fontSize: 9 * PT }}>
            {n + 1} / {paginas.length}
          </p>
        </div>
      ))}
    </div>
  )
}
