import { useEffect, useRef, useState, type KeyboardEvent } from 'react'
import Boton from '../componentes/Boton'
import CabeceraApp from '../componentes/CabeceraApp'
import MarcoPantalla, { type Tamano } from '../componentes/MarcoPantalla'
import PieApp from '../componentes/PieApp'
import Sigla from '../componentes/Sigla'
import { CATEGORIAS } from '../datos/categorias'
import { FILTRO_DETECTORES, FILTRO_FAMILIAS, FILTRO_SEVERIDADES, REGLAS_MUESTRA, TOTAL_REGLAS, type ReglaCatalogo } from '../datos/catalogo'

type Filtros = { familias: string[]; detectores: string[]; severidades: string[] }
const SIN_FILTROS: Filtros = { familias: [], detectores: [], severidades: [] }
const cuantos = (f: Filtros) => f.familias.length + f.detectores.length + f.severidades.length
const cat = (id: string) => CATEGORIAS.find((c) => c.id === id)!
const ENLACE_ANALIZADOR = { texto: 'Analizador', href: '#analizador-vacio' }

// Prototipo: sin filtros ni búsqueda se anuncia el total del catálogo; con ellos se filtran las seis de muestra
function useCatalogo(inicial: Filtros) {
  const [filtros, setFiltros] = useState<Filtros>(inicial)
  const [busqueda, setBusqueda] = useState('')
  const q = busqueda.trim().toLowerCase()
  const lista = REGLAS_MUESTRA.filter(
    (r) =>
      (!filtros.familias.length || filtros.familias.includes(r.familia)) &&
      (!filtros.detectores.length || filtros.detectores.includes(r.detector)) &&
      // Las reglas de muestra aún no traen severidad: filtrar por ella no deja ninguna
      !filtros.severidades.length &&
      (!q || [r.nombre, r.id, r.frase].some((t) => t.toLowerCase().includes(q))),
  )
  const recuento = cuantos(filtros) || q ? lista.length : TOTAL_REGLAS
  return { filtros, setFiltros, busqueda, setBusqueda, lista, recuento, quitar: () => setFiltros(SIN_FILTROS) }
}

function Muestra({ familia }: { familia: string }) {
  return (
    <span aria-hidden="true" className={`subrayado sub-${familia} font-texto text-cuerpo leading-none`}>
      Abc
    </span>
  )
}

function Buscador({ valor, onCambiar }: { valor: string; onCambiar: (v: string) => void }) {
  return (
    <div data-capa="buscador" className="flex flex-col gap-2">
      <label htmlFor="buscar-reglas" className="font-ui text-base font-bold">Buscar por nombre, id o explicación</label>
      <input
        id="buscar-reglas"
        type="search"
        value={valor}
        onChange={(e) => onCambiar(e.target.value)}
        className="h-12 w-full rounded-boton border border-ink-2 bg-bg px-4 font-ui text-base text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
      />
    </div>
  )
}

function Casillas({ legend, opciones, marcadas, onCambiar }: { legend: string; opciones: { id: string; nombre: string; familia?: string }[]; marcadas: string[]; onCambiar: (v: string[]) => void }) {
  const alternar = (id: string) => onCambiar(marcadas.includes(id) ? marcadas.filter((m) => m !== id) : [...marcadas, id])
  return (
    <fieldset data-capa={`filtro – ${legend}`} className="flex min-w-0 flex-col">
      <legend className="mb-1 font-ui text-base font-bold">{legend}</legend>
      {opciones.map((o) => (
        <label key={o.id} className="flex min-h-[44px] cursor-pointer items-center gap-3 font-ui text-secundario text-ink">
          <input type="checkbox" checked={marcadas.includes(o.id)} onChange={() => alternar(o.id)} className="size-5 shrink-0 cursor-pointer accent-accent" />
          {o.familia && <Muestra familia={o.familia} />}
          <span>{o.nombre}</span>
        </label>
      ))}
    </fieldset>
  )
}

function GruposFiltros({ filtros, onCambiar }: { filtros: Filtros; onCambiar: (f: Filtros) => void }) {
  return {
    familia: (
      <Casillas legend="Familia" opciones={FILTRO_FAMILIAS.map((f) => ({ ...f, familia: f.id }))} marcadas={filtros.familias} onCambiar={(v) => onCambiar({ ...filtros, familias: v })} />
    ),
    detector: (
      <Casillas legend="Detector" opciones={FILTRO_DETECTORES.map((d) => ({ id: d, nombre: d }))} marcadas={filtros.detectores} onCambiar={(v) => onCambiar({ ...filtros, detectores: v })} />
    ),
    severidad: (
      <Casillas legend="Severidad" opciones={FILTRO_SEVERIDADES.map((d) => ({ id: d, nombre: d }))} marcadas={filtros.severidades} onCambiar={(v) => onCambiar({ ...filtros, severidades: v })} />
    ),
  }
}

function Recuento({ n }: { n: number }) {
  return (
    <p data-capa="recuento" aria-live="polite" className="font-ui text-base font-bold">
      {n} {n === 1 ? 'regla' : 'reglas'}
    </p>
  )
}

function TarjetaCatalogo({ r }: { r: ReglaCatalogo }) {
  const c = cat(r.familia)
  return (
    <li
      data-capa={`regla – ${r.nombre} (${c.sigla})`}
      className={`flex gap-4 rounded-tarjeta border p-5 ${r.informativa ? 'border-dashed border-ink-2/50 bg-card' : 'border-line bg-bg'}`}
    >
      <div className="flex shrink-0 flex-col items-center gap-2 pt-0.5">
        <Muestra familia={r.familia} />
        <Sigla letra={c.sigla} color={c.color} />
      </div>
      <div className="flex min-w-0 flex-col gap-1">
        <a href={`#regla/${r.id}`} className="self-start font-ui text-titulo-tarjeta font-bold text-accent underline underline-offset-4">
          {r.nombre}
        </a>
        <p className={`font-ui text-base ${r.informativa ? 'text-ink-2' : 'text-ink'}`}>{r.frase}</p>
        <p className="font-ui text-secundario break-words text-ink-2">
          {r.id} · {r.paquete} · {r.detector} · {r.evidencia}
        </p>
      </div>
    </li>
  )
}

function Lista({ lista, quitar }: { lista: ReglaCatalogo[]; quitar: () => void }) {
  if (!lista.length)
    return (
      <div data-capa="sin-resultados" className="flex flex-col items-start gap-4 rounded-tarjeta border border-line bg-card p-8">
        <p className="font-ui text-titulo-tarjeta font-bold">Ninguna regla con esos filtros.</p>
        <Boton variante="secundario" onClick={quitar} className="cursor-pointer">Quitar filtros</Boton>
      </div>
    )
  return (
    <ul data-capa="lista-reglas" aria-label="Reglas" className="flex flex-col gap-3">
      {lista.map((r) => <TarjetaCatalogo key={r.id} r={r} />)}
    </ul>
  )
}

function Encabezado() {
  return (
    <div className="flex flex-col gap-2">
      <h1 className="font-ui text-titulo-pantalla font-bold">Catálogo de reglas</h1>
      <p className="max-w-columna-texto font-texto text-cuerpo text-ink-2">
        Todas las reglas de los dos paquetes incluidos. Cada una tiene su propia página, con su explicación, sus fuentes y sus ejemplos.
      </p>
    </div>
  )
}

// Hoja inferior modal de filtros (móvil): asa-botón, X, Escape y fondo cierran; el foco vuelve al botón «Filtros»
function HojaFiltros({ inicial, onAplicar, onCerrar }: { inicial: Filtros; onAplicar: (f: Filtros) => void; onCerrar: () => void }) {
  const [borrador, setBorrador] = useState(inicial)
  const [grande, setGrande] = useState(false)
  const hoja = useRef<HTMLDivElement>(null)
  const g = GruposFiltros({ filtros: borrador, onCambiar: setBorrador })

  useEffect(() => {
    hoja.current?.querySelector<HTMLElement>('h2')?.focus({ preventScroll: true })
    const esc = (e: globalThis.KeyboardEvent) => e.key === 'Escape' && onCerrar()
    document.addEventListener('keydown', esc)
    return () => document.removeEventListener('keydown', esc)
  }, [onCerrar])

  const atrapar = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== 'Tab' || !hoja.current) return
    const f = [...hoja.current.querySelectorAll<HTMLElement>('button:not([disabled]), input')].filter((el) => el.checkVisibility())
    const i = f.indexOf(document.activeElement as HTMLElement)
    e.preventDefault()
    f[e.shiftKey ? (i <= 0 ? f.length - 1 : i - 1) : i === f.length - 1 ? 0 : i + 1]?.focus()
  }

  return (
    <>
      <div data-capa="fondo-oscurecido" aria-hidden="true" onClick={onCerrar} className="absolute inset-0 z-10 bg-black/40" />
      <div
        ref={hoja}
        role="dialog"
        aria-modal="true"
        aria-labelledby="t-hoja-filtros"
        data-capa="hoja-inferior"
        onKeyDown={atrapar}
        className="absolute inset-x-0 bottom-0 z-20 flex flex-col rounded-t-tarjeta border-t border-line bg-bg font-ui text-ink"
        style={{ maxHeight: grande ? '90%' : '60%' }}
      >
        <button type="button" aria-label="Cambiar tamaño" data-capa="asa" onClick={() => setGrande((v) => !v)} className="flex h-11 w-full shrink-0 cursor-pointer items-center justify-center">
          <span aria-hidden="true" className="h-1 w-10 rounded-full bg-ink-2" />
        </button>
        <div className="flex items-center justify-between gap-3 px-4">
          <h2 id="t-hoja-filtros" tabIndex={-1} className="text-titulo-tarjeta font-bold">Filtros</h2>
          <button type="button" aria-label="Cerrar" data-capa="boton-cerrar" onClick={onCerrar} className="-mr-2 inline-flex size-11 cursor-pointer items-center justify-center rounded-boton hover:bg-card">
            <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M5 5l10 10M15 5L5 15" />
            </svg>
          </button>
        </div>
        <div className="flex min-h-0 flex-col gap-6 overflow-y-auto px-4 py-3">
          {g.familia}
          {g.detector}
          {g.severidad}
        </div>
        <div data-capa="acciones-filtros" className="flex flex-col gap-3 border-t border-line p-4">
          <Boton onClick={() => onAplicar(borrador)} className="w-full cursor-pointer">Aplicar</Boton>
          <Boton variante="secundario" onClick={() => setBorrador(SIN_FILTROS)} className="w-full cursor-pointer">Quitar filtros</Boton>
        </div>
      </div>
    </>
  )
}

type Props = { tamano: Tamano; nombreTamano?: string; inicial?: Filtros; hojaAbierta?: boolean }

export default function Catalogo({ tamano, nombreTamano, inicial = SIN_FILTROS, hojaAbierta = false }: Props) {
  const c = useCatalogo(inicial)
  const [hoja, setHoja] = useState(hojaAbierta)
  const botonFiltros = useRef<HTMLButtonElement>(null)
  const g = GruposFiltros({ filtros: c.filtros, onCambiar: c.setFiltros })
  const n = cuantos(c.filtros)

  const cerrarHoja = () => {
    setHoja(false)
    requestAnimationFrame(() => botonFiltros.current?.focus())
  }

  if (tamano === 'movil') {
    return (
      <MarcoPantalla pantalla="Catálogo de reglas" tamano={tamano} nombreTamano={nombreTamano}>
        <div data-capa="pantalla-movil" className="relative h-[844px] overflow-hidden">
          <div inert={hoja} className="h-full overflow-y-auto">
            <div className="flex flex-col gap-6 px-4">
              <CabeceraApp compacta enlace={ENLACE_ANALIZADOR} />
              <main data-capa="catalogo" className="flex flex-col gap-6">
                <Encabezado />
                <Buscador valor={c.busqueda} onCambiar={c.setBusqueda} />
                <div data-capa="barra-filtros" className="flex items-center justify-between gap-4">
                  <Boton ref={botonFiltros} variante="secundario" aria-haspopup="dialog" aria-expanded={hoja} onClick={() => setHoja(true)} className="cursor-pointer">
                    {n ? `Filtros (${n})` : 'Filtros'}
                  </Boton>
                  <Recuento n={c.recuento} />
                </div>
                <Lista lista={c.lista} quitar={c.quitar} />
              </main>
              <PieApp />
            </div>
          </div>
          {hoja && (
            <HojaFiltros
              inicial={c.filtros}
              onCerrar={cerrarHoja}
              onAplicar={(f) => {
                c.setFiltros(f)
                cerrarHoja()
              }}
            />
          )}
        </div>
      </MarcoPantalla>
    )
  }

  const tableta = tamano === 'tableta'
  const acciones = (
    <div data-capa="acciones-filtros" className={`flex gap-4 ${tableta ? 'items-center justify-between' : 'flex-col items-start'}`}>
      <Boton variante="secundario" onClick={c.quitar} className="cursor-pointer">Quitar filtros</Boton>
      <Recuento n={c.recuento} />
    </div>
  )

  return (
    <MarcoPantalla pantalla="Catálogo de reglas" tamano={tamano} nombreTamano={nombreTamano}>
      <div className={`flex flex-col ${tableta ? 'gap-8 px-10' : 'gap-10 px-16'}`}>
        <CabeceraApp enlace={ENLACE_ANALIZADOR} />
        <main data-capa="catalogo" className="flex flex-col gap-8">
          <Encabezado />
          <Buscador valor={c.busqueda} onCambiar={c.setBusqueda} />
          {tableta ? (
            <div data-capa="filtros" className="flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-8">
                {g.familia}
                <div className="flex flex-col gap-6">
                  {g.detector}
                  {g.severidad}
                </div>
              </div>
              {acciones}
            </div>
          ) : (
            <div data-capa="filtros" className="grid grid-cols-[minmax(0,1.5fr)_1fr_1fr_auto] gap-10">
              {g.familia}
              {g.detector}
              {g.severidad}
              {acciones}
            </div>
          )}
          <Lista lista={c.lista} quitar={c.quitar} />
        </main>
        <PieApp />
      </div>
    </MarcoPantalla>
  )
}

export function CatalogoSinResultados() {
  return <Catalogo tamano="escritorio" nombreTamano="Sin resultados" inicial={{ familias: ['gramatica'], detectores: [], severidades: ['alta'] }} />
}

export function CatalogoFiltros() {
  return <Catalogo tamano="movil" nombreTamano="Móvil · Filtros" hojaAbierta />
}
