import Boton from '../componentes/Boton'
import CabeceraApp from '../componentes/CabeceraApp'
import MarcoPantalla, { type Tamano } from '../componentes/MarcoPantalla'
import PieApp from '../componentes/PieApp'
import Sigla from '../componentes/Sigla'
import { CATEGORIAS } from '../datos/categorias'

const discurso = CATEGORIAS.find((c) => c.id === 'discurso')!
const h2 = 'font-ui text-titulo-tarjeta font-bold'
const relleno = 'italic text-ink-2'

function Seccion({ titulo, children }: { titulo: string; children: React.ReactNode }) {
  const id = `ficha-${titulo.toLowerCase().replace(/\s+/g, '-')}`
  return (
    <section data-capa={`seccion – ${titulo}`} aria-labelledby={id} className="flex flex-col gap-3">
      <h2 id={id} className={h2}>{titulo}</h2>
      {children}
    </section>
  )
}

function Externo() {
  return (
    <svg aria-hidden="true" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
      <path d="M9 3h4v4M13 3L7 9M11 9.5V13H3V5h3.5" />
    </svg>
  )
}

// Tramo de ejemplo: mismo aspecto que en el analizador, pero no interactivo
function Ademas() {
  return (
    <>
      <span className="subrayado sub-discurso px-[2px]">Además</span>
      <span aria-hidden="true" className="ml-[2px] align-super font-ui text-[11px] leading-none text-ink-2">D</span>
    </>
  )
}

const DATOS: [string, string][] = [
  ['Detector', 'estructural'],
  ['Peso', '2'],
  ['Severidad', 'baja'],
  ['Nivel de evidencia', 'medido en inglés'],
  ['Origen de la lista', '[origen de la ficha]'],
]

export default function FichaRegla({ tamano }: { tamano: Tamano }) {
  const movil = tamano === 'movil'
  return (
    <MarcoPantalla pantalla="Ficha de regla" tamano={tamano}>
      <div className={`flex flex-col ${movil ? 'gap-6 px-4' : tamano === 'tableta' ? 'gap-8 px-10' : 'gap-10 px-16'}`}>
        <CabeceraApp compacta={movil} enlace={{ texto: 'Analizador', href: '#analizador-vacio' }} />
        <main data-capa="ficha-regla" className="mx-auto flex w-full max-w-columna-texto flex-col gap-8 pb-4">
          <div className="flex flex-col gap-4">
            <p data-capa="pastilla-familia" className="inline-flex items-center gap-3 self-start rounded-full border border-line py-1.5 pl-3 pr-4 font-ui text-secundario">
              <span aria-hidden="true" className="subrayado sub-discurso font-texto text-cuerpo leading-none">Abc</span>
              <Sigla letra={discurso.sigla} color={discurso.color} />
              <span>Discurso · RadiografIA 0.1.0</span>
            </p>
            <div className="flex flex-col gap-1">
              <h1 className="font-ui text-titulo-pantalla font-bold">Conector repetido</h1>
              <p className="font-ui text-secundario text-ink-2">disc-marcador-repetido</p>
            </div>
            <p className="font-texto text-cuerpo">El mismo conector al principio de tres frases o más, como «Además» una y otra vez.</p>
          </div>

          <Seccion titulo="Qué hacer">
            <p className="font-texto text-cuerpo">Cambia alguno de los conectores repetidos o quítalo: muchas veces la frase se entiende sin él.</p>
          </Seccion>

          <Seccion titulo="Explicación">
            <p data-capa="relleno" className={`font-texto text-cuerpo ${relleno}`}>[Explicación de la ficha: cuatro o cinco frases con sus citas.]</p>
          </Seccion>

          <Seccion titulo="Excepciones">
            <ul className="list-disc pl-6 font-texto text-cuerpo">
              <li data-capa="relleno" className={relleno}>[Excepción declarada en la ficha.]</li>
              <li data-capa="relleno" className={relleno}>[Excepción declarada en la ficha.]</li>
            </ul>
          </Seccion>

          <Seccion titulo="Datos de la regla">
            <dl className="grid grid-cols-[max-content_1fr] gap-x-4 gap-y-2 rounded-tarjeta border border-line bg-card p-4 font-ui text-base">
              {DATOS.map(([k, v]) => (
                <div key={k} className="contents">
                  <dt className="font-bold">{k}:</dt>
                  <dd className={v.startsWith('[') ? relleno : ''}>{v}</dd>
                </div>
              ))}
            </dl>
          </Seccion>

          <Seccion titulo="Fuentes">
            <ul className="flex flex-col">
              {[1, 2].map((n) => (
                <li key={n}>
                  <a href={`#fuente-${n}`} data-capa="relleno" className="inline-flex min-h-[44px] items-center gap-2 font-ui text-base text-accent underline underline-offset-4">
                    <span className="italic">[Título de la fuente {n}]</span>
                    <Externo />
                    <span className="sr-only">(enlace externo)</span>
                  </a>
                </li>
              ))}
            </ul>
          </Seccion>

          <Seccion titulo="Ejemplos">
            <div className="flex flex-col gap-4">
              <figure data-capa="ejemplo – Positivo" className="flex flex-col gap-2 rounded-tarjeta border border-line p-4">
                <figcaption className="font-ui text-secundario font-bold">Positivo</figcaption>
                <p className="font-texto text-cuerpo">
                  <Ademas />, el plan llega tarde. <Ademas />, nadie lo ha leído. <Ademas />, el presupuesto no cuadra.
                </p>
              </figure>
              <figure data-capa="ejemplo – Negativo" className="flex flex-col gap-2 rounded-tarjeta border border-line p-4">
                <figcaption className="font-ui text-secundario font-bold">Negativo</figcaption>
                <p className="font-texto text-cuerpo">El plan llega tarde; nadie lo ha leído y el presupuesto no cuadra.</p>
              </figure>
            </div>
          </Seccion>

          <div data-capa="acciones" className={`flex gap-4 ${movil ? 'flex-col items-stretch' : 'flex-wrap items-center'}`}>
            <Boton onClick={() => (window.location.hash = '#analizador-vacio')} className={`cursor-pointer ${movil ? 'w-full' : ''}`}>Probar en el analizador</Boton>
            <a href="#catalogo" className="inline-flex min-h-[44px] items-center justify-center font-ui text-base font-bold text-accent underline underline-offset-4">Volver al catálogo</a>
          </div>
        </main>
        <PieApp />
      </div>
    </MarcoPantalla>
  )
}
