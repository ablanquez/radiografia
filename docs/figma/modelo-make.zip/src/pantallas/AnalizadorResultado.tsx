import { useRef, useState } from 'react'
import { AccionesResultado, Detalle, EspanolCorrecto, Familias, LoQueMasPesa, TextoPlegado } from '../componentes/BloquesResultado'
import CabeceraApp from '../componentes/CabeceraApp'
import MarcoPantalla, { type Tamano } from '../componentes/MarcoPantalla'
import PastillaResultado from '../componentes/PastillaResultado'
import { TarjetaAnclada, useReglaActiva, VistaMovilConHoja } from '../componentes/PanelRegla'
import PieApp from '../componentes/PieApp'
import { ALTO_BARRA, BarraPestanas, PanelDatos, PanelPestana, PanelReglas, PanelTexto, type Pestana } from '../componentes/ResultadoMovil'
import VistaTexto from '../componentes/VistaTexto'
import { RESULTADO } from '../datos/resultadoEjemplo'
import { PASTILLAS, type VariantePastilla } from '../datos/pastilla'

function useCapas() {
  const [ocultas, setOcultas] = useState<Set<string>>(new Set())
  const alternar = (id: string) =>
    setOcultas((s) => {
      const n = new Set(s)
      n.has(id) ? n.delete(id) : n.add(id)
      return n
    })
  return { ocultas, alternar }
}

type Props = { tamano: Tamano; pantalla?: string; abierto?: number | null; pestana?: Pestana; nombreTamano?: string }

export default function AnalizadorResultado({ tamano, pantalla = 'Analizador con resultado', abierto = null, pestana = 'texto', nombreTamano }: Props) {
  const [activa, setActiva] = useState<Pestana>(pestana)
  const { ocultas, alternar } = useCapas()
  const lienzo = useRef<HTMLDivElement>(null)
  const regla = useReglaActiva(lienzo, abierto)
  const texto = <VistaTexto ocultas={ocultas} activo={regla.activo} onActivar={regla.abrir} />

  if (tamano === 'movil') {
    return (
      <MarcoPantalla pantalla={pantalla} tamano={tamano} nombreTamano={nombreTamano}>
        <VistaMovilConHoja regla={regla} barra={<BarraPestanas activa={activa} onCambiar={setActiva} />}>
          <div
            ref={lienzo}
            className="flex flex-col gap-6 px-4"
            style={{ paddingBottom: `calc(${ALTO_BARRA + 1}px + env(safe-area-inset-bottom))` }}
          >
            <CabeceraApp compacta />
            <main data-capa="contenido" className="flex flex-col gap-8">
              <section data-capa="resultado" aria-label="Resultado" className="flex flex-col gap-6">
                <PastillaResultado variante={RESULTADO.variante} compacta />
                <LoQueMasPesa />
              </section>
              <PanelPestana id="texto" activa={activa}>
                <PanelTexto texto={texto} />
              </PanelPestana>
              <PanelPestana id="reglas" activa={activa}>
                <PanelReglas ocultas={ocultas} alternar={alternar} />
              </PanelPestana>
              <PanelPestana id="datos" activa={activa}>
                <PanelDatos />
              </PanelPestana>
            </main>
          </div>
        </VistaMovilConHoja>
      </MarcoPantalla>
    )
  }

  if (tamano === 'tableta') {
    return (
      <MarcoPantalla pantalla={pantalla} tamano={tamano}>
        <div ref={lienzo} className="relative flex flex-col gap-8 px-10">
          <CabeceraApp />
          <main data-capa="contenido" className="flex flex-col gap-8">
            <TextoPlegado />
            <section data-capa="resultado" aria-label="Resultado" className="flex flex-col gap-8">
              <PastillaResultado variante={RESULTADO.variante} />
              <LoQueMasPesa />
            </section>
            {texto}
            <Familias ocultas={ocultas} alternar={alternar} />
            <Detalle />
            <EspanolCorrecto />
            <AccionesResultado />
          </main>
          <PieApp />
          <TarjetaAnclada regla={regla} />
        </div>
      </MarcoPantalla>
    )
  }

  return (
    <MarcoPantalla pantalla={pantalla} tamano={tamano}>
      <div ref={lienzo} className="relative flex flex-col gap-10 px-16">
        <CabeceraApp />
        <main data-capa="contenido" className="flex items-start justify-between gap-16">
          <section data-capa="columna-texto" aria-label="Tu texto" className="flex w-columna-texto flex-col gap-8">
            <TextoPlegado />
            {texto}
          </section>
          <aside data-capa="resultado" aria-label="Resultado" className="sticky top-8 flex w-columna-resultado shrink-0 flex-col gap-8">
            <PastillaResultado variante={RESULTADO.variante} />
            <LoQueMasPesa />
            <Familias ocultas={ocultas} alternar={alternar} />
            <Detalle />
            <EspanolCorrecto />
            <AccionesResultado />
          </aside>
        </main>
        <PieApp />
        <TarjetaAnclada regla={regla} />
      </div>
    </MarcoPantalla>
  )
}

export function PastillaVariantes() {
  const variantes = Object.keys(PASTILLAS) as VariantePastilla[]
  return (
    <MarcoPantalla pantalla="Pastilla" tamano="escritorio" nombreTamano="Variantes">
      <div className="flex flex-col gap-8 px-16 py-12">
        {variantes.map((v) => (
          <div key={v} data-capa={`variante – ${PASTILLAS[v].etiqueta}`} className="w-columna-resultado">
            <PastillaResultado variante={v} />
          </div>
        ))}
        <div data-capa="variante – Dentro de lo normal · texto corto" className="w-columna-resultado">
          <PastillaResultado variante="normal" textoCorto />
        </div>
      </div>
    </MarcoPantalla>
  )
}

export function AnalizadorResultadoReglas() {
  return <AnalizadorResultado tamano="movil" pestana="reglas" nombreTamano="Móvil · Reglas" />
}

export function AnalizadorResultadoDatos() {
  return <AnalizadorResultado tamano="movil" pestana="datos" nombreTamano="Móvil · Datos" />
}
