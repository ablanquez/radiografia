import CabeceraApp from '../componentes/CabeceraApp'
import FormularioAnalisis, { type EstadoFormulario } from '../componentes/FormularioAnalisis'
import MarcoPantalla, { type Tamano } from '../componentes/MarcoPantalla'
import PieApp from '../componentes/PieApp'

function HuecoResultado() {
  return (
    <aside data-capa="resultado" aria-label="Resultado" className="font-ui text-base text-ink-2">
      Aquí verás el resultado.
    </aside>
  )
}

export default function AnalizadorVacio({ tamano }: { tamano: Tamano }) {
  if (tamano === 'movil') {
    return (
      <MarcoPantalla pantalla="Analizador vacío" tamano={tamano}>
        <div className="flex flex-col gap-6 px-4">
          <CabeceraApp compacta />
          <main data-capa="contenido">
            <FormularioAnalisis movil />
          </main>
          <PieApp />
        </div>
      </MarcoPantalla>
    )
  }

  if (tamano === 'tableta') {
    return (
      <MarcoPantalla pantalla="Analizador vacío" tamano={tamano}>
        <div className="flex flex-col gap-8 px-10">
          <CabeceraApp />
          <main data-capa="contenido" className="flex max-w-columna-texto flex-col gap-8">
            <FormularioAnalisis />
            <HuecoResultado />
          </main>
          <PieApp />
        </div>
      </MarcoPantalla>
    )
  }

  return (
    <MarcoPantalla pantalla="Analizador vacío" tamano={tamano}>
      <div className="flex flex-col gap-10 px-16">
        <CabeceraApp />
        <main data-capa="contenido" className="flex items-start justify-between gap-16">
          <section data-capa="columna-texto" aria-label="Tu texto" className="w-columna-texto max-w-columna-texto">
            <FormularioAnalisis />
          </section>
          <section data-capa="columna-resultado" className="sticky top-8 w-columna-resultado shrink-0 rounded-tarjeta border border-line p-6">
            <HuecoResultado />
          </section>
        </main>
        <PieApp />
      </div>
    </MarcoPantalla>
  )
}

const ESTADOS: { estado: EstadoFormulario; titulo: string }[] = [
  { estado: 'vacio', titulo: 'Cuadro vacío' },
  { estado: 'insuficiente', titulo: 'Texto insuficiente' },
  { estado: 'error-paquete', titulo: 'Error de carga de paquete' },
]

export function AnalizadorVacioEstados() {
  return (
    <MarcoPantalla pantalla="Analizador vacío" tamano="escritorio" nombreTamano="Estados">
      <div className="grid grid-cols-3 gap-10 px-10 py-10">
        {ESTADOS.map(({ estado, titulo }) => (
          <section key={estado} data-capa={`estado – ${titulo}`} className="flex flex-col gap-4">
            <h2 className="border-b border-line pb-2 font-ui text-secundario font-bold text-ink-2">{titulo}</h2>
            <FormularioAnalisis estado={estado} />
          </section>
        ))}
      </div>
    </MarcoPantalla>
  )
}
