import MarcoPantalla from '../componentes/MarcoPantalla'

// Geometría común (viewBox 512, zona segura: círculo de 409 px centrado).
// Hoja 220 × 290, subida 5 px para el centrado óptico; esquinas a 184 px del centro.
const HOJA_MUESCA = 'M146 108H302L366 172V398H146Z'
const PLIEGUE = 'M302 108V172H366Z'
const PLIEGUE_SEPARADO = 'M302 122V172H352Z' // deja 10 px de aire en la diagonal
const LINEAS = 'M186 196H290V228H186ZM186 252H326V284H186ZM186 340H286V372H186Z'
const SUBRAYADO = 'M186 296H326V316H186Z'

const svg = (cuerpo: string) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">\n${cuerpo}\n</svg>`

const VARIANTES = [
  {
    letra: 'a',
    nombre: 'Fondo oscuro, hoja blanca',
    codigo: svg(`  <rect width="512" height="512" rx="96" fill="#1A1A1A"/>
  <path d="${HOJA_MUESCA} ${PLIEGUE_SEPARADO}" fill="#FFFFFF"/>
  <path d="${LINEAS}" fill="#1A1A1A"/>
  <path d="${SUBRAYADO}" fill="#332288"/>`),
  },
  {
    letra: 'b',
    nombre: 'Sin fondo, hoja oscura',
    codigo: svg(`  <path d="${HOJA_MUESCA}" fill="#1A1A1A"/>
  <path d="${PLIEGUE}" fill="#4A4A4A"/>
  <path d="${LINEAS}" fill="#FFFFFF"/>
  <path d="${SUBRAYADO}" fill="#CC6677"/>`),
  },
  {
    letra: 'c',
    nombre: 'Círculo, hoja en negativo',
    codigo: svg(`  <circle cx="256" cy="256" r="204" fill="#332288"/>
  <path d="${HOJA_MUESCA} ${PLIEGUE_SEPARADO}" fill="#FFFFFF"/>
  <path d="${LINEAS}" fill="#332288"/>
  <path d="${SUBRAYADO}" fill="#D55E00"/>`),
  },
]

const TAMANOS = [180, 64, 32, 16]

function Icono({ codigo, tam, nombre }: { codigo: string; tam: number; nombre: string }) {
  return (
    <span
      role="img"
      aria-label={`${nombre}, ${tam} px`}
      data-capa={`icono ${tam}`}
      className="block shrink-0 [&>svg]:block [&>svg]:size-full"
      style={{ width: tam, height: tam }}
      dangerouslySetInnerHTML={{ __html: codigo }}
    />
  )
}

export default function IconoVariantes() {
  return (
    <div className="flex flex-col gap-10">
      <MarcoPantalla pantalla="Icono" tamano="escritorio" nombreTamano="Variantes">
        <div className="grid grid-cols-3 gap-8 p-16">
          {VARIANTES.map((v) => (
            <figure key={v.letra} data-capa={`variante ${v.letra}`} className="flex flex-col items-center gap-4">
              {[
                ['bg-bg border border-line', 'sobre blanco'],
                ['bg-ink', 'sobre #1A1A1A'],
              ].map(([fondo, etiqueta]) => (
                <div key={etiqueta} data-capa={`fondo ${etiqueta}`} className={`flex w-full items-end justify-center gap-5 rounded-tarjeta p-6 ${fondo}`}>
                  {TAMANOS.map((t) => <Icono key={t} codigo={v.codigo} tam={t} nombre={`Variante ${v.letra}, ${etiqueta}`} />)}
                </div>
              ))}
              <figcaption className="font-ui text-titulo-tarjeta font-bold">
                {v.letra}
                <span className="block text-center text-secundario font-normal text-ink-2">{v.nombre}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </MarcoPantalla>
      <section aria-label="Código SVG" className="mx-auto flex w-[1280px] flex-col gap-6">
        {VARIANTES.map((v) => (
          <div key={v.letra} className="flex flex-col gap-2">
            <h2 className="font-ui text-base font-bold">Variante {v.letra} · {v.nombre}</h2>
            <pre className="overflow-x-auto rounded-tarjeta border border-line bg-bg p-4 font-mono text-[13px] leading-relaxed text-ink">{v.codigo}</pre>
          </div>
        ))}
      </section>
    </div>
  )
}
