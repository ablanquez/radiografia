import Boton from '../componentes/Boton'
import MarcoPantalla, { type Tamano } from '../componentes/MarcoPantalla'
import Sigla from '../componentes/Sigla'
import TramoSubrayado from '../componentes/TramoSubrayado'
import { CATEGORIAS } from '../datos/categorias'

const NEUTROS = [
  ['bg', '#FFFFFF'],
  ['ink', '#1A1A1A'],
  ['ink-2', '#4A4A4A'],
  ['line', '#D9D9D9'],
  ['card', '#F5F5F5'],
  ['accent', '#332288'],
]

const ESCALA = [
  ['Título de pantalla · 28', 'text-titulo-pantalla font-ui font-bold'],
  ['Título de tarjeta · 20', 'text-titulo-tarjeta font-ui font-bold'],
  ['Cuerpo · 18', 'text-cuerpo font-texto'],
  ['Secundario · 15', 'text-secundario font-ui text-ink-2'],
]

export default function Muestrario({ tamano }: { tamano: Tamano }) {
  const movil = tamano === 'movil'
  const pad = movil ? 'px-4 py-6' : tamano === 'tableta' ? 'px-10 py-10' : 'px-16 py-12'
  return (
    <MarcoPantalla pantalla="Muestrario" tamano={tamano}>
      <main data-capa="muestrario" className={`${pad} flex flex-col gap-10`}>
        <h1 className="font-ui text-titulo-pantalla font-bold">Muestrario de tokens</h1>

        <section data-capa="leyenda" aria-labelledby="t-cat" className="flex flex-col gap-4">
          <h2 id="t-cat" className="font-ui text-titulo-tarjeta font-bold">Categorías</h2>
          <ul className={`grid gap-x-10 gap-y-5 ${tamano === 'escritorio' ? 'grid-cols-2' : 'grid-cols-1'}`}>
            {CATEGORIAS.map((c) => (
              <li key={c.id} data-capa={`categoria – ${c.nombre} (${c.sigla})`} className="flex flex-col gap-1.5">
                <div className="flex items-center gap-2">
                  <Sigla letra={c.sigla} color={c.color} />
                  <span className="font-ui text-base font-bold">{c.nombre}</span>
                  <span className="font-ui text-secundario text-ink-2">· {c.estilo}</span>
                </div>
                <p className="font-texto text-cuerpo">
                  Esto es un <TramoSubrayado texto="tramo de ejemplo" familias={[c.id]} regla={c.nombre} /> dentro de una frase.
                </p>
              </li>
            ))}
          </ul>
        </section>

        <section data-capa="neutros" aria-labelledby="t-neu" className="flex flex-col gap-4">
          <h2 id="t-neu" className="font-ui text-titulo-tarjeta font-bold">Neutros</h2>
          <ul className={`grid gap-4 ${movil ? 'grid-cols-2' : 'grid-cols-6'}`}>
            {NEUTROS.map(([n, h]) => (
              <li key={n} data-capa={`neutro – ${n}`} className="flex flex-col gap-2">
                <span className="h-16 rounded-tarjeta border border-ink-2/40" style={{ background: h }} />
                <span className="font-ui text-base font-bold">{n}</span>
                <span className="font-ui text-secundario text-ink-2">{h}</span>
              </li>
            ))}
          </ul>
        </section>

        <section data-capa="escala" aria-labelledby="t-esc" className="flex flex-col gap-3">
          <h2 id="t-esc" className="font-ui text-titulo-tarjeta font-bold">Escala</h2>
          {ESCALA.map(([t, c]) => (
            <p key={t} className={c}>{t}</p>
          ))}
        </section>

        <section data-capa="botones" aria-labelledby="t-bot" className="flex flex-col gap-3">
          <h2 id="t-bot" className="font-ui text-titulo-tarjeta font-bold">Botones · 44 px</h2>
          <div className="flex flex-wrap gap-4">
            <Boton>Principal</Boton>
            <Boton variante="secundario">Secundario</Boton>
          </div>
          <p className="font-ui text-secundario text-ink-2">Estado de foco visible (fijo para revisión):</p>
          <div className="flex flex-wrap gap-4">
            <Boton className="outline-2 outline-offset-2 outline-accent">Principal</Boton>
            <Boton variante="secundario" className="outline-2 outline-offset-2 outline-accent">Secundario</Boton>
          </div>
        </section>
      </main>
    </MarcoPantalla>
  )
}
