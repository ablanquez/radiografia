import MarcoPantalla, { type Tamano } from '../componentes/MarcoPantalla'
import TarjetaRegla from '../componentes/TarjetaRegla'
import { FICHA_CONECTOR, FICHA_PAQUETE_PROPIO, PRIMER_ADEMAS } from '../datos/reglas'
import AnalizadorResultado from './AnalizadorResultado'

// Estado abierto fijo para revisión: el primer «Además» con su tarjeta (u hoja en móvil)
export default function TarjetaReglaPantalla({ tamano }: { tamano: Tamano }) {
  return <AnalizadorResultado tamano={tamano} pantalla="Tarjeta de regla" abierto={PRIMER_ADEMAS} />
}

const ESTADOS = [
  { nombre: '¿Por qué lo miramos? desplegado', ficha: FICHA_CONECTOR, porQueAbierto: true, primera: false },
  { nombre: 'Regla de paquete propio', ficha: FICHA_PAQUETE_PROPIO, porQueAbierto: true, primera: false },
  { nombre: 'Primera señal: «Anterior» desactivado', ficha: FICHA_CONECTOR, porQueAbierto: false, primera: true },
]

export function TarjetaReglaEstados() {
  return (
    <MarcoPantalla pantalla="Tarjeta de regla" tamano="escritorio" nombreTamano="Estados">
      <div className="flex items-start gap-10 px-16 py-12">
        {ESTADOS.map((e) => (
          <figure key={e.nombre} data-capa={`estado – ${e.nombre}`} className="flex flex-col gap-4">
            <figcaption className="font-ui text-secundario font-bold text-ink-2">{e.nombre}</figcaption>
            <TarjetaRegla modo="estatica" ficha={e.ficha} porQueAbierto={e.porQueAbierto} primera={e.primera} pico={{ lado: 'arriba', x: 48 }} />
          </figure>
        ))}
      </div>
    </MarcoPantalla>
  )
}
